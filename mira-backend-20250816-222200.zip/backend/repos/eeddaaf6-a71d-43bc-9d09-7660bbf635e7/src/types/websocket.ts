// src/types/websocket.ts
export interface WsChunk {
  type: 'chunk';
  content: string;
  mood?: string;  // Only mood is visible, not persona
}

export interface WsAside {
  type: 'aside';
  emotional_cue: string;
  intensity?: number;
}

export interface WsArtifact {
  type: 'artifact';
  artifact: {
    id: string;
    name: string;
    content: string;
    artifact_type: 'code' | 'document' | 'data';
    language?: string;
  };
}

// REMOVED: WsPersonaUpdate - personas change invisibly
// REMOVED: WsMemoryStats - too mechanical for natural conversation

export interface WsError {
  type: 'error';
  message: string;
  code?: string;
}

export interface WsDone {
  type: 'done';
}

export interface WsPing {
  type: 'ping';
}

export interface WsPong {
  type: 'pong';
}

// New web search message types
export interface WsSearchResults {
  type: 'search_results';
  sources: Array<{
    title: string;
    url: string;
    snippet: string;
    published_date?: string;
    domain?: string;
  }>;
  summary?: string;
  provider?: string;
}

export interface WsSearchStatus {
  type: 'search_status';
  status: 'searching' | 'complete' | 'error';
  message?: string;
}

export type WsServerMessage = 
  | WsChunk 
  | WsAside 
  | WsArtifact
  | WsError 
  | WsDone
  | WsSearchResults  // Added for web search results
  | WsSearchStatus;  // Added for search status updates

export interface WsClientMessage {
  type: 'chat' | 'message' | 'typing';  // FIXED: Added 'chat' to support backend expectation
  content?: string;
  persona?: string | null;  // DEPRECATED - will be ignored by backend
  active?: boolean;
  session_id?: string | null;
  project_id?: string | null;  // Added for project context
  web_search?: boolean;  // Added for web search requests
}
