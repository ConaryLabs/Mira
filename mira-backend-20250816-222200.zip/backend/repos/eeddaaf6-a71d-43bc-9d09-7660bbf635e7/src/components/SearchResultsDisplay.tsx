// src/components/SearchResultsDisplay.tsx
import React, { useState } from 'react';
import { Globe, ExternalLink, Clock, ChevronDown, ChevronUp, Search } from 'lucide-react';
import clsx from 'clsx';

interface SearchSource {
  title: string;
  url: string;
  snippet: string;
  published_date?: string;
  domain?: string;
}

interface SearchResultsProps {
  sources: SearchSource[];
  summary?: string;
  provider?: string;
  isDark: boolean;
}

export const SearchResultsDisplay: React.FC<SearchResultsProps> = ({ 
  sources, 
  summary, 
  provider = 'Web',
  isDark 
}) => {
  const [isExpanded, setIsExpanded] = useState(true);
  const [expandedSources, setExpandedSources] = useState<Set<number>>(new Set());

  const toggleSource = (index: number) => {
    const newExpanded = new Set(expandedSources);
    if (newExpanded.has(index)) {
      newExpanded.delete(index);
    } else {
      newExpanded.add(index);
    }
    setExpandedSources(newExpanded);
  };

  const getDomainFromUrl = (url: string): string => {
    try {
      const domain = new URL(url).hostname;
      return domain.replace('www.', '');
    } catch {
      return 'website';
    }
  };

  return (
    <div className={clsx(
      'rounded-lg p-3 my-2 transition-all',
      isDark 
        ? 'bg-blue-900/20 border border-blue-700/30' 
        : 'bg-blue-50 border border-blue-200'
    )}>
      {/* Header */}
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2">
          <Search size={16} className={isDark ? 'text-blue-400' : 'text-blue-600'} />
          <span className={clsx(
            'text-sm font-medium',
            isDark ? 'text-blue-400' : 'text-blue-700'
          )}>
            Web Search Results
          </span>
          {provider && (
            <span className={clsx(
              'text-xs px-2 py-0.5 rounded-full',
              isDark 
                ? 'bg-blue-800/50 text-blue-300' 
                : 'bg-blue-100 text-blue-600'
            )}>
              via {provider}
            </span>
          )}
        </div>
        <button
          onClick={() => setIsExpanded(!isExpanded)}
          className={clsx(
            'p-1 rounded transition-colors',
            isDark 
              ? 'hover:bg-blue-800/30' 
              : 'hover:bg-blue-100'
          )}
          aria-label={isExpanded ? 'Collapse results' : 'Expand results'}
        >
          {isExpanded ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
        </button>
      </div>

      {/* Summary */}
      {summary && isExpanded && (
        <div className={clsx(
          'text-sm mb-3 p-2 rounded',
          isDark 
            ? 'bg-gray-800/50 text-gray-300' 
            : 'bg-white text-gray-700'
        )}>
          {summary}
        </div>
      )}

      {/* Sources */}
      {isExpanded && (
        <div className="space-y-2">
          {sources.map((source, index) => (
            <div
              key={index}
              className={clsx(
                'rounded-lg p-2 transition-all',
                isDark 
                  ? 'bg-gray-800/30 hover:bg-gray-800/50' 
                  : 'bg-white hover:bg-gray-50',
                'border',
                isDark ? 'border-gray-700/50' : 'border-gray-200'
              )}
            >
              {/* Source Header */}
              <div className="flex items-start justify-between gap-2">
                <div className="flex-1 min-w-0">
                  <button
                    onClick={() => toggleSource(index)}
                    className="w-full text-left"
                  >
                    <h4 className={clsx(
                      'font-medium text-sm line-clamp-1 hover:underline',
                      isDark ? 'text-gray-100' : 'text-gray-900'
                    )}>
                      {source.title}
                    </h4>
                  </button>
                  <div className="flex items-center gap-2 mt-1">
                    <Globe size={12} className="text-gray-400" />
                    <span className="text-xs text-gray-500 dark:text-gray-400">
                      {source.domain || getDomainFromUrl(source.url)}
                    </span>
                    {source.published_date && (
                      <>
                        <Clock size={12} className="text-gray-400" />
                        <span className="text-xs text-gray-500 dark:text-gray-400">
                          {source.published_date}
                        </span>
                      </>
                    )}
                  </div>
                </div>
                <a
                  href={source.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={clsx(
                    'p-1.5 rounded transition-colors',
                    isDark 
                      ? 'hover:bg-blue-800/30 text-blue-400' 
                      : 'hover:bg-blue-100 text-blue-600'
                  )}
                  aria-label="Open in new tab"
                >
                  <ExternalLink size={14} />
                </a>
              </div>

              {/* Source Content */}
              {expandedSources.has(index) && (
                <div className={clsx(
                  'mt-2 text-sm',
                  isDark ? 'text-gray-300' : 'text-gray-600'
                )}>
                  <p className="line-clamp-3">{source.snippet}</p>
                  <a
                    href={source.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className={clsx(
                      'inline-flex items-center gap-1 mt-2 text-xs',
                      isDark 
                        ? 'text-blue-400 hover:text-blue-300' 
                        : 'text-blue-600 hover:text-blue-700'
                    )}
                  >
                    Read more <ExternalLink size={10} />
                  </a>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Show count when collapsed */}
      {!isExpanded && (
        <div className={clsx(
          'text-xs',
          isDark ? 'text-gray-400' : 'text-gray-500'
        )}>
          {sources.length} sources found
        </div>
      )}
    </div>
  );
};
