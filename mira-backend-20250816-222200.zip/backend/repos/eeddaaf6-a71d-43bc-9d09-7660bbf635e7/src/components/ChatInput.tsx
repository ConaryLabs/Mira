// src/components/ChatInput.tsx
import React, { useState, useRef } from 'react';
import { Send, Search, Globe, X } from 'lucide-react';
import clsx from 'clsx';

interface ChatInputProps {
  onSend: (message: string, options?: { webSearch?: boolean }) => void;
  disabled: boolean;
  isDark: boolean;
}

export const ChatInput: React.FC<ChatInputProps> = ({ onSend, disabled, isDark }) => {
  const [input, setInput] = useState('');
  const [webSearchEnabled, setWebSearchEnabled] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleSubmit = () => {
    if (!input.trim() || disabled) return;
    
    // Send with web search flag if enabled
    onSend(input, { webSearch: webSearchEnabled });
    setInput('');
    setWebSearchEnabled(false); // Reset after sending
    inputRef.current?.focus();
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  const toggleWebSearch = () => {
    setWebSearchEnabled(!webSearchEnabled);
    inputRef.current?.focus();
  };

  return (
    <div className="relative z-10 p-4 border-t border-gray-700/50 dark:border-gray-700/50">
      {/* Web Search Indicator */}
      {webSearchEnabled && (
        <div className="mb-2 flex items-center justify-between px-2">
          <div className="flex items-center gap-2 text-sm">
            <Globe 
              size={14} 
              className="text-blue-500 animate-pulse" 
            />
            <span className={isDark ? 'text-blue-400' : 'text-blue-600'}>
              Web search enabled - I'll search the internet for current information
            </span>
          </div>
          <button
            onClick={() => setWebSearchEnabled(false)}
            className="p-1 rounded hover:bg-gray-200 dark:hover:bg-gray-800 transition-colors"
            aria-label="Disable web search"
          >
            <X size={14} className="text-gray-500" />
          </button>
        </div>
      )}
      
      <div className="flex gap-2">
        {/* Web Search Toggle Button */}
        <button
          onClick={toggleWebSearch}
          disabled={disabled}
          className={clsx(
            'p-2 rounded-lg transition-all',
            webSearchEnabled
              ? isDark
                ? 'bg-blue-600 text-white hover:bg-blue-700'
                : 'bg-blue-500 text-white hover:bg-blue-600'
              : isDark
                ? 'bg-gray-800 text-gray-400 hover:bg-gray-700 hover:text-gray-300'
                : 'bg-gray-100 text-gray-600 hover:bg-gray-200 hover:text-gray-700',
            disabled && 'opacity-50 cursor-not-allowed'
          )}
          title={webSearchEnabled ? 'Web search is ON' : 'Enable web search'}
        >
          <Search size={20} />
        </button>

        {/* Input Field */}
        <input
          ref={inputRef}
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyPress={handleKeyPress}
          placeholder={
            disabled 
              ? "Waiting for connection..." 
              : webSearchEnabled 
                ? "Ask me anything - I'll search the web..."
                : "Say something..."
          }
          disabled={disabled}
          className={clsx(
            'flex-1 px-4 py-2 rounded-lg transition-all',
            'focus:outline-none focus:ring-2',
            webSearchEnabled 
              ? 'focus:ring-blue-500' 
              : 'focus:ring-purple-500',
            isDark
              ? 'bg-gray-800 text-gray-100 placeholder-gray-500'
              : 'bg-white text-gray-900 placeholder-gray-400 shadow-sm',
            webSearchEnabled && (isDark 
              ? 'ring-1 ring-blue-500/30' 
              : 'ring-1 ring-blue-400/30')
          )}
        />

        {/* Send Button */}
        <button
          onClick={handleSubmit}
          disabled={disabled || !input.trim()}
          className={clsx(
            'p-2 rounded-lg transition-all',
            disabled || !input.trim()
              ? 'bg-gray-700 text-gray-500 cursor-not-allowed'
              : webSearchEnabled
                ? 'bg-blue-600 hover:bg-blue-700 text-white'
                : 'bg-purple-600 hover:bg-purple-700 text-white'
          )}
        >
          <Send size={20} />
        </button>
      </div>

      {/* Quick search suggestions */}
      {webSearchEnabled && input.length === 0 && (
        <div className="mt-2 flex flex-wrap gap-2">
          <span className="text-xs text-gray-500 dark:text-gray-400">Try:</span>
          {[
            'latest news',
            'weather today',
            'stock prices',
            'what happened today'
          ].map(suggestion => (
            <button
              key={suggestion}
              onClick={() => {
                setInput(suggestion);
                inputRef.current?.focus();
              }}
              className={clsx(
                'text-xs px-2 py-1 rounded-full transition-colors',
                isDark
                  ? 'bg-gray-800 hover:bg-gray-700 text-gray-400'
                  : 'bg-gray-100 hover:bg-gray-200 text-gray-600'
              )}
            >
              {suggestion}
            </button>
          ))}
        </div>
      )}
    </div>
  );
};
