// src/llm/memory_eval.rs
//! GPT‑5 Functions API for memory evaluation (salience/tags/etc).

use anyhow::{Context, Result};
use serde_json::{json, Value};

use crate::llm::client::OpenAIClient;
use crate::llm::schema::{EvaluateMemoryRequest, EvaluateMemoryResponse};

impl OpenAIClient {
    /// Call GPT‑5 via **/responses** with a forced function call to `evaluate_memory`.
    pub async fn evaluate_memory(&self, req: EvaluateMemoryRequest) -> Result<EvaluateMemoryResponse> {
        // The function schema is carried on the request (built in schema.rs)
        let body = json!({
            "model": "gpt-5",
            "input": [{
                "role": "user",
                "content": [{ "type": "input_text", "text": req.content }]
            }],
            "functions": [ req.function_schema ],
            "function_call": { "name": "evaluate_memory" },
            "response_format": { "type": "json_object" },
            "parameters": {
                "verbosity": "low",
                "reasoning_effort": "minimal",
                "max_output_tokens": 256
            }
        });

        let v = self.post_response(body).await?;

        // Prefer new tool_calls shape
        if let Some(args) = v
            .pointer("/choices/0/message/tool_calls/0/function/arguments")
            .and_then(|x| x.as_str())
        {
            let parsed: EvaluateMemoryResponse =
                serde_json::from_str(args).context("Failed to parse function arguments JSON")?;
            return Ok(parsed);
        }

        // Fallback: legacy function_call.arguments
        if let Some(args) = v
            .pointer("/choices/0/message/function_call/arguments")
            .and_then(|x| x.as_str())
        {
            let parsed: EvaluateMemoryResponse =
                serde_json::from_str(args).context("Failed to parse function arguments JSON")?;
            return Ok(parsed);
        }

        // As a last resort, try direct output (model may have emitted JSON as text)
        if let Some(txt) = v
            .pointer("/output/0/text")
            .and_then(|x| x.as_str())
        {
            let parsed: EvaluateMemoryResponse =
                serde_json::from_str(txt).context("Failed to parse JSON from output text")?;
            return Ok(parsed);
        }

        Err(anyhow::anyhow!(
            "No function call arguments returned from GPT‑5 for evaluate_memory"
        ))
    }
}
