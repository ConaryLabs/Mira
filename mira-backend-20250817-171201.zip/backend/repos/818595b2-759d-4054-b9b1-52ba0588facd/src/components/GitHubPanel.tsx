// src/components/GitHubPanel.tsx
import React, { useState, useEffect } from 'react';
import { 
  GitBranch, 
  Github, 
  FolderGit2, 
  History,
  FileCode,
  X,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react';
import { GitFileBrowser } from './GitFileBrowser';
import { BranchSelector } from './BranchSelector';
import { CommitHistory } from './CommitHistory';
import { FileEditor } from './FileEditor';
import { gitApi, GitRepoAttachment } from '../services/gitApi';

interface GitHubPanelProps {
  projectId: string;
  isDark?: boolean;
  onClose?: () => void;
}

type TabType = 'files' | 'commits' | 'editor';

export const GitHubPanel: React.FC<GitHubPanelProps> = ({
  projectId,
  isDark = false,
  onClose,
}) => {
  const [repos, setRepos] = useState<GitRepoAttachment[]>([]);
  const [selectedRepo, setSelectedRepo] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<TabType>('files');
  const [selectedFile, setSelectedFile] = useState<string | null>(null);
  const [currentBranch, setCurrentBranch] = useState<string>('main');
  const [isCollapsed, setIsCollapsed] = useState(false);

  useEffect(() => {
    loadRepos();
  }, [projectId]);

  const loadRepos = async () => {
    try {
      const response = await gitApi.listRepos(projectId);
      const importedRepos = response.repos.filter(r => r.import_status === 'Imported');
      setRepos(importedRepos);
      
      if (importedRepos.length > 0 && !selectedRepo) {
        setSelectedRepo(importedRepos[0].id);
      }
    } catch (error) {
      console.error('Failed to load repos:', error);
    }
  };

  const handleFileSelect = (filePath: string) => {
    setSelectedFile(filePath);
    setActiveTab('editor');
  };

  const handleBranchChange = (branch: string) => {
    setCurrentBranch(branch);
    // Refresh file tree when branch changes
    setSelectedFile(null);
    setActiveTab('files');
  };

  const handleCommitSelect = (commitId: string) => {
    console.log('Selected commit:', commitId);
    // Could open a diff viewer here
  };

  const getRepoName = (repo: GitRepoAttachment) => {
    return repo.repo_url.split('/').pop()?.replace('.git', '') || 'Unknown repo';
  };

  if (repos.length === 0) {
    return (
      <div className={`h-full flex flex-col ${isDark ? 'bg-gray-900' : 'bg-white'}`}>
        <div className={`px-4 py-3 border-b flex items-center justify-between ${
          isDark ? 'border-gray-700 bg-gray-800' : 'border-gray-200 bg-gray-50'
        }`}>
          <div className="flex items-center gap-2">
            <Github className="w-5 h-5" />
            <h2 className={`text-lg font-semibold ${isDark ? 'text-gray-100' : 'text-gray-900'}`}>
              GitHub Integration
            </h2>
          </div>
          {onClose && (
            <button
              onClick={onClose}
              className={`p-1 rounded hover:bg-gray-${isDark ? '700' : '200'}`}
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>
        <div className="flex-1 flex items-center justify-center">
          <div className={`text-center ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>
            <FolderGit2 className="w-12 h-12 mx-auto mb-3 opacity-50" />
            <p className="text-sm">No repositories attached to this project</p>
            <p className="text-xs mt-1">Attach a repository from the project sidebar</p>
          </div>
        </div>
      </div>
    );
  }

  const selectedRepoData = repos.find(r => r.id === selectedRepo);

  if (isCollapsed) {
    return (
      <div className={`h-full w-12 flex flex-col ${isDark ? 'bg-gray-900' : 'bg-white'} border-l ${
        isDark ? 'border-gray-700' : 'border-gray-200'
      }`}>
        <button
          onClick={() => setIsCollapsed(false)}
          className={`p-3 hover:bg-gray-${isDark ? '800' : '100'}`}
          title="Expand GitHub panel"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>
      </div>
    );
  }

  return (
    <div className={`h-full flex flex-col ${isDark ? 'bg-gray-900' : 'bg-white'}`}>
      {/* Header */}
      <div className={`px-4 py-3 border-b ${isDark ? 'border-gray-700 bg-gray-800' : 'border-gray-200 bg-gray-50'}`}>
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Github className="w-5 h-5" />
            <h2 className={`text-lg font-semibold ${isDark ? 'text-gray-100' : 'text-gray-900'}`}>
              GitHub Integration
            </h2>
          </div>
          <div className="flex items-center gap-1">
            <button
              onClick={() => setIsCollapsed(true)}
              className={`p-1 rounded hover:bg-gray-${isDark ? '700' : '200'}`}
              title="Collapse panel"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
            {onClose && (
              <button
                onClick={onClose}
                className={`p-1 rounded hover:bg-gray-${isDark ? '700' : '200'}`}
              >
                <X className="w-5 h-5" />
              </button>
            )}
          </div>
        </div>

        {/* Repository Selector */}
        {repos.length > 1 && (
          <select
            value={selectedRepo || ''}
            onChange={(e) => setSelectedRepo(e.target.value)}
            className={`w-full px-2 py-1 text-sm border rounded focus:outline-none focus:ring-1 focus:ring-blue-500 mb-3 ${
              isDark 
                ? 'border-gray-600 bg-gray-700 text-gray-100' 
                : 'border-gray-300 bg-white text-gray-900'
            }`}
          >
            {repos.map(repo => (
              <option key={repo.id} value={repo.id}>
                {getRepoName(repo)}
              </option>
            ))}
          </select>
        )}

        {/* Branch Selector */}
        {selectedRepo && (
          <BranchSelector
            projectId={projectId}
            attachmentId={selectedRepo}
            isDark={isDark}
            onBranchChange={handleBranchChange}
          />
        )}
      </div>

      {/* Tabs */}
      <div className={`flex border-b ${isDark ? 'border-gray-700' : 'border-gray-200'}`}>
        <button
          onClick={() => setActiveTab('files')}
          className={`flex items-center gap-2 px-4 py-2 text-sm font-medium transition-colors ${
            activeTab === 'files'
              ? isDark
                ? 'text-blue-400 border-b-2 border-blue-400'
                : 'text-blue-600 border-b-2 border-blue-600'
              : isDark
                ? 'text-gray-400 hover:text-gray-200'
                : 'text-gray-600 hover:text-gray-900'
          }`}
        >
          <FolderGit2 className="w-4 h-4" />
          Files
        </button>
        <button
          onClick={() => setActiveTab('commits')}
          className={`flex items-center gap-2 px-4 py-2 text-sm font-medium transition-colors ${
            activeTab === 'commits'
              ? isDark
                ? 'text-blue-400 border-b-2 border-blue-400'
                : 'text-blue-600 border-b-2 border-blue-600'
              : isDark
                ? 'text-gray-400 hover:text-gray-200'
                : 'text-gray-600 hover:text-gray-900'
          }`}
        >
          <History className="w-4 h-4" />
          Commits
        </button>
        {selectedFile && (
          <button
            onClick={() => setActiveTab('editor')}
            className={`flex items-center gap-2 px-4 py-2 text-sm font-medium transition-colors ${
              activeTab === 'editor'
                ? isDark
                  ? 'text-blue-400 border-b-2 border-blue-400'
                  : 'text-blue-600 border-b-2 border-blue-600'
                : isDark
                  ? 'text-gray-400 hover:text-gray-200'
                  : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            <FileCode className="w-4 h-4" />
            Editor
            {selectedFile && (
              <span className={`text-xs px-2 py-0.5 rounded ${
                isDark ? 'bg-gray-700' : 'bg-gray-200'
              }`}>
                {selectedFile.split('/').pop()}
              </span>
            )}
          </button>
        )}
      </div>

      {/* Content */}
      <div className="flex-1 overflow-hidden">
        {activeTab === 'files' && selectedRepo && (
          <GitFileBrowser
            projectId={projectId}
            repoId={selectedRepo}
            isDark={isDark}
            onFileSelect={handleFileSelect}
            selectedFile={selectedFile || undefined}
          />
        )}
        
        {activeTab === 'commits' && selectedRepo && (
          <CommitHistory
            projectId={projectId}
            attachmentId={selectedRepo}
            isDark={isDark}
            onCommitSelect={handleCommitSelect}
          />
        )}
        
        {activeTab === 'editor' && selectedFile && selectedRepo && (
          <FileEditor
            projectId={projectId}
            attachmentId={selectedRepo}
            filePath={selectedFile}
            isDark={isDark}
            onClose={() => {
              setSelectedFile(null);
              setActiveTab('files');
            }}
          />
        )}
      </div>
    </div>
  );
};
