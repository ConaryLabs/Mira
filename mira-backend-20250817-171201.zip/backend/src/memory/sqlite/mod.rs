//! SQLite-backed memory store (implements MemoryStore trait).

pub mod store;
pub mod query;
pub mod migration;
