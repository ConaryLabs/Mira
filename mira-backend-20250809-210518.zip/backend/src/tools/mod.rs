// src/tools/mod.rs

pub mod mira_import;

// Web search module removed - Claude handles web search natively
// All web_search related exports have been removed since we're using
// Claude's built-in web search capabilities instead
