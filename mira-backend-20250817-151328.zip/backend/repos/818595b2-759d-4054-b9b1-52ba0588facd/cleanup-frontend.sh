#!/bin/bash
# cleanup-frontend.sh - Quick cleanup for frontend repository

# Remove node_modules from Git tracking (keeps local files)
git rm -r --cached node_modules

# Remove dist/build directories from Git tracking
git rm -r --cached dist
git rm -r --cached build

# Remove any .env files from tracking
git rm --cached .env
git rm --cached .env.local
git rm --cached .env.*.local

# Remove OS files
git rm --cached .DS_Store
git rm --cached **/.DS_Store

# Remove editor files
git rm -r --cached .vscode
git rm -r --cached .idea

# Add the .gitignore file
git add .gitignore

# Commit everything
git commit -m "Add .gitignore and remove tracked files that should be ignored"

# Push to remote
git push origin main

echo "✅ Frontend repository cleaned up!"
echo "Your node_modules and dist folders are now ignored."
