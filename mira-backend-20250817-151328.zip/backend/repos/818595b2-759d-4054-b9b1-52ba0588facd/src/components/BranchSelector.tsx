// src/components/BranchSelector.tsx
import React, { useState, useEffect } from 'react';
import { GitBranch, Check, ChevronDown, Loader2 } from 'lucide-react';
import { API_BASE_URL } from '../services/config';

interface Branch {
  name: string;
  is_current: boolean;
  last_commit_id: string;
  last_commit_message: string;
  last_commit_time: number;
}

interface BranchSelectorProps {
  projectId: string;
  attachmentId: string;
  isDark?: boolean;
  onBranchChange?: (branch: string) => void;
}

export const BranchSelector: React.FC<BranchSelectorProps> = ({
  projectId,
  attachmentId,
  isDark = false,
  onBranchChange,
}) => {
  const [branches, setBranches] = useState<Branch[]>([]);
  const [currentBranch, setCurrentBranch] = useState<string>('');
  const [isOpen, setIsOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [switching, setSwitching] = useState(false);

  useEffect(() => {
    loadBranches();
  }, [projectId, attachmentId]);

  useEffect(() => {
    // Close dropdown when clicking outside
    const handleClickOutside = (event: MouseEvent) => {
      const target = event.target as HTMLElement;
      if (!target.closest('.branch-selector')) {
        setIsOpen(false);
      }
    };

    if (isOpen) {
      document.addEventListener('click', handleClickOutside);
      return () => document.removeEventListener('click', handleClickOutside);
    }
  }, [isOpen]);

  const loadBranches = async () => {
    try {
      setLoading(true);
      const response = await fetch(
        `${API_BASE_URL}/projects/${projectId}/git/${attachmentId}/branches`
      );
      
      if (!response.ok) {
        throw new Error('Failed to load branches');
      }
      
      const data = await response.json();
      setBranches(data.branches || []);
      
      const current = data.branches?.find((b: Branch) => b.is_current);
      if (current) {
        setCurrentBranch(current.name);
      }
    } catch (error) {
      console.error('Failed to load branches:', error);
      setBranches([]);
    } finally {
      setLoading(false);
    }
  };

  const switchBranch = async (branchName: string) => {
    if (branchName === currentBranch) {
      setIsOpen(false);
      return;
    }

    setSwitching(true);
    try {
      const response = await fetch(
        `${API_BASE_URL}/projects/${projectId}/git/${attachmentId}/branches/switch`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ branch_name: branchName }),
        }
      );

      if (!response.ok) {
        throw new Error('Failed to switch branch');
      }

      setCurrentBranch(branchName);
      onBranchChange?.(branchName);
      setIsOpen(false);
      
      // Update the branches list to reflect the new current branch
      setBranches(branches.map(b => ({
        ...b,
        is_current: b.name === branchName
      })));
    } catch (error) {
      console.error('Failed to switch branch:', error);
      alert('Failed to switch branch. Please try again.');
    } finally {
      setSwitching(false);
    }
  };

  const formatCommitMessage = (message: string) => {
    // Truncate long commit messages
    return message.length > 40 ? message.substring(0, 40) + '...' : message;
  };

  if (loading) {
    return (
      <div className={`flex items-center gap-2 px-3 py-1.5 text-sm rounded border ${
        isDark
          ? 'bg-gray-800 border-gray-600 text-gray-400'
          : 'bg-white border-gray-300 text-gray-500'
      }`}>
        <Loader2 className="w-4 h-4 animate-spin" />
        <span>Loading branches...</span>
      </div>
    );
  }

  return (
    <div className="relative branch-selector">
      <button
        onClick={() => setIsOpen(!isOpen)}
        disabled={switching || branches.length === 0}
        className={`flex items-center gap-2 px-3 py-1.5 text-sm rounded border transition-colors ${
          isDark
            ? 'bg-gray-800 border-gray-600 text-gray-200 hover:bg-gray-700'
            : 'bg-white border-gray-300 text-gray-700 hover:bg-gray-50'
        } ${(switching || branches.length === 0) ? 'opacity-50 cursor-not-allowed' : ''}`}
      >
        {switching ? (
          <Loader2 className="w-4 h-4 animate-spin" />
        ) : (
          <GitBranch className="w-4 h-4" />
        )}
        <span className="font-medium">
          {currentBranch || (branches.length === 0 ? 'No branches' : 'Select branch')}
        </span>
        {branches.length > 0 && <ChevronDown className="w-3 h-3" />}
      </button>

      {isOpen && branches.length > 0 && (
        <div className={`absolute top-full left-0 mt-1 w-80 max-h-64 overflow-y-auto rounded-lg shadow-lg border ${
          isDark ? 'bg-gray-800 border-gray-600' : 'bg-white border-gray-200'
        } py-1 z-50`}>
          {branches.map((branch) => (
            <button
              key={branch.name}
              onClick={() => switchBranch(branch.name)}
              disabled={switching}
              className={`w-full px-3 py-2 text-left transition-colors ${
                branch.is_current
                  ? isDark
                    ? 'bg-blue-900/30 text-blue-400'
                    : 'bg-blue-50 text-blue-700'
                  : isDark
                    ? 'hover:bg-gray-700 text-gray-200'
                    : 'hover:bg-gray-50 text-gray-700'
              } ${switching ? 'opacity-50 cursor-not-allowed' : ''}`}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="font-medium text-sm">{branch.name}</span>
                  {branch.is_current && <Check className="w-4 h-4 text-green-500" />}
                </div>
              </div>
              <div className={`text-xs mt-1 ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>
                {formatCommitMessage(branch.last_commit_message)}
              </div>
            </button>
          ))}
        </div>
      )}
    </div>
  );
};
