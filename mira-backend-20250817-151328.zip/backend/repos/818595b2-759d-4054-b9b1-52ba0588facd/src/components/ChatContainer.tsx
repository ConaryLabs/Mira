import React, { useState, useRef, useEffect, useCallback, useMemo } from 'react';
import { useWebSocket } from '../hooks/useWebSocket';
import { useTheme } from '../hooks/useTheme';
import { MessageBubble } from './MessageBubble';
import { ChatInput } from './ChatInput';
import { MoodBackground } from './MoodBackground';
import { ThinkingBubble } from './ThinkingBubble';
import ProjectSidebar from './ProjectSidebar';
import SidebarToggle from './SidebarToggle';
import ArtifactViewer from './ArtifactViewer';
import ArtifactToggle from './ArtifactToggle';
import type { Message, Aside } from '../types/messages';
import type { WsServerMessage } from '../types/websocket';
import { Sun, Moon } from 'lucide-react';

interface Project {
  id: string;
  name: string;
  created_at?: string;
  updated_at?: string;
}

interface SessionArtifact {
  id: string;
  name: string;
  content: string;
  artifact_type: 'code' | 'document' | 'data';
  language?: string;
  created_at: string;
  updated_at: string;
}

export const ChatContainer: React.FC = () => {
  // --- PROJECT STATE ---
  const [projects, setProjects] = useState<Project[]>([]);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false); // COLLAPSED by default!
  const [currentProjectId, setCurrentProjectId] = useState<string | null>(null);

  const fetchProjects = () => {
    fetch('/api/projects')
      .then(res => res.json())
      .then(data => {
        console.log('Fetched projects:', data);
        setProjects(data.projects || []);
      })
      .catch(err => {
        console.error('Failed to fetch projects:', err);
      });
  };

  useEffect(() => {
    fetchProjects();
  }, []);

  const handleProjectCreate = (name: string) => {
    fetch('/api/projects', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name }),
    })
      .then(res => res.json())
      .then(newProject => {
        setProjects(prev => [...prev, newProject]);
      })
      .catch(err => {
        console.error('Failed to create project:', err);
      });
  };

  const handleProjectSelect = (projectId: string) => {
    setCurrentProjectId(projectId);
    setIsSidebarOpen(false);
    setSelectedArtifactId(null);
    setShowArtifacts(false);
  };

  // --- ARTIFACT/CHAT STATE ---
  const [messages, setMessages] = useState<Message[]>([]);
  const [currentMood, setCurrentMood] = useState('present');
  const [isThinking, setIsThinking] = useState(false);
  const [connectionError, setConnectionError] = useState('');
  const [isLoadingHistory, setIsLoadingHistory] = useState(true);
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const [hasMoreHistory, setHasMoreHistory] = useState(true);
  const [historyOffset, setHistoryOffset] = useState(0);
  const [showArtifacts, setShowArtifacts] = useState(false);
  const [selectedArtifactId, setSelectedArtifactId] = useState<string | null>(null);
  const [artifactCount, setArtifactCount] = useState(0);
  const [sessionArtifacts, setSessionArtifacts] = useState<SessionArtifact[]>([]);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const messagesContainerRef = useRef<HTMLDivElement>(null);
  const currentStreamId = useRef<string>('');

  const { isDark, toggleTheme } = useTheme();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (!isLoadingMore) {
      scrollToBottom();
    }
  }, [messages, isLoadingMore]);

  useEffect(() => {
    if (currentProjectId) {
      fetch(`/api/projects/${currentProjectId}/artifacts`)
        .then(res => res.json())
        .then(data => {
          setArtifactCount(data.artifacts?.length || 0);
        })
        .catch(err => console.error('Failed to fetch artifacts:', err));
    } else {
      setArtifactCount(0);
      setShowArtifacts(false);
    }
  }, [currentProjectId]);

  const getMoodColor = (mood: string) => {
    const moodColors: Record<string, string> = {
      playful: 'border-purple-500',
      caring: 'border-blue-500',
      sassy: 'border-rose-500',
      melancholy: 'border-indigo-600',
      fierce: 'border-red-600',
      intense: 'border-violet-700',
      present: 'border-gray-400',
      thinking: 'border-purple-400',
    };
    return moodColors[mood] || moodColors.present;
  };

  const handleArtifactClick = (artifactId: string) => {
    setSelectedArtifactId(artifactId);
    setShowArtifacts(true);
  };

  const handleServerMessage = useCallback((msg: WsServerMessage) => {
    switch (msg.type) {
      case 'chunk':
        if (msg.content && msg.content.trim()) setIsThinking(false);
        if (msg.mood) setCurrentMood(msg.mood);
        setMessages(prev => {
          const firstMsg = prev[0];
          if (firstMsg && firstMsg.id === currentStreamId.current && firstMsg.isStreaming) {
            return [
              {
                ...firstMsg,
                content: firstMsg.content + msg.content,
                mood: msg.mood || firstMsg.mood,
              },
              ...prev.slice(1)
            ];
          } else if (msg.content && msg.content.trim()) {
            const newId = Date.now().toString();
            currentStreamId.current = newId;
            return [
              {
                id: newId,
                role: 'mira' as const,
                content: msg.content,
                mood: msg.mood || currentMood,
                timestamp: new Date(),
                isStreaming: true,
              },
              ...prev
            ];
          }
          return prev;
        });
        break;
      case 'aside':
        const asideMessage: Message = {
          id: Date.now().toString(),
          role: 'aside',
          content: msg.emotional_cue,
          mood: currentMood,
          timestamp: new Date(),
          isStreaming: false,
          intensity: msg.intensity,
        };
        setMessages(prev => [asideMessage, ...prev]);
        break;
      case 'artifact':
        if (msg.artifact) {
          const newArtifact: SessionArtifact = {
            id: msg.artifact.id,
            name: msg.artifact.name,
            content: msg.artifact.content,
            artifact_type: msg.artifact.artifact_type,
            language: msg.artifact.language,
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString(),
          };
          setSessionArtifacts(prev => [...prev, newArtifact]);
        }
        break;
      case 'done':
        const streamId = currentStreamId.current;
        currentStreamId.current = '';
        setMessages(prev =>
          prev.map(msg =>
            msg.id === streamId ? { ...msg, isStreaming: false } : msg
          )
        );
        setIsThinking(false);
        break;
      case 'error':
        setConnectionError(msg.message || 'An error occurred');
        setIsThinking(false);
        setTimeout(() => setConnectionError(''), 5000);
        break;
      default:
        console.warn('Unknown message type:', msg);
    }
  }, [currentMood]);

  const loadChatHistory = useCallback(async (offset = 0) => {
    if (offset === 0) setIsLoadingHistory(true);
    else setIsLoadingMore(true);
    try {
      const response = await fetch(`/api/chat/history?limit=30&offset=${offset}`, {
        method: 'GET',
        headers: { 'Content-Type': 'application/json' },
      });
      if (response.ok) {
        const data = await response.json();
        console.log("Chat history data:", data); // Debug
        const formattedMessages: Message[] = data.messages.map((msg: any) => ({
          id: msg.id || Date.now().toString() + Math.random(),
          role: msg.role === 'assistant' ? 'mira' : msg.role,
          content: msg.content,
          mood: msg.tags?.[0] || 'present',
          timestamp: new Date(msg.timestamp),
          isStreaming: false,
        }));
        if (offset === 0) {
          setMessages(formattedMessages);
          const lastMiraMsg = formattedMessages.filter(m => m.role === 'mira').pop();
          if (lastMiraMsg?.mood) setCurrentMood(lastMiraMsg.mood);
        } else {
          setMessages(prev => [...prev, ...formattedMessages]);
        }
        setHasMoreHistory(formattedMessages.length === 30);
        setHistoryOffset(offset + formattedMessages.length);
      }
    } catch (error) {
      console.error('Failed to load chat history:', error);
    } finally {
      setIsLoadingHistory(false);
      setIsLoadingMore(false);
    }
  }, []);

  const handleScroll = useCallback(() => {
    if (!messagesContainerRef.current || isLoadingMore || !hasMoreHistory) return;
    const { scrollTop } = messagesContainerRef.current;
    if (scrollTop === 0) {
      loadChatHistory(historyOffset);
    }
  }, [historyOffset, isLoadingMore, hasMoreHistory, loadChatHistory]);

  const webSocketUrl = useMemo(() => {
    if (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1') {
      return 'ws://localhost:8080/ws/chat';
    }
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const host = window.location.host;
    return `${protocol}//${host}/ws/chat`;
  }, []);

  const { isConnected, send } = useWebSocket({
    url: webSocketUrl,
    onMessage: handleServerMessage,
    onConnect: () => {
      setConnectionError('');
      loadChatHistory();
    },
    onDisconnect: () => {},
    onError: (error) => {
      setConnectionError('Connection error occurred');
      setTimeout(() => setConnectionError(''), 5000);
    }
  });

  const handleSendMessage = useCallback((content: string) => {
    if (!content.trim()) return;
    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content,
      timestamp: new Date(),
    };
    setMessages(prev => [userMessage, ...prev]);
    setIsThinking(true);
    setConnectionError('');
    // FIXED: Changed from 'message' to 'chat'
    send({
      type: 'chat',  // <-- THIS IS THE FIX: Changed from 'message' to 'chat'
      content,
      project_id: currentProjectId,
    });
  }, [send, currentProjectId]);

  // Debug: Always log sidebar state!
  console.log("Rendering ProjectSidebar with isOpen:", isSidebarOpen, "projects:", projects);

  return (
    <div className={`relative flex h-screen bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-gray-100 ${isDark ? 'dark-scrollbar' : 'light-scrollbar'}`}>
      {/* Sidebar overlays (fixed), rest is chat area. */}
      <ProjectSidebar
        isOpen={isSidebarOpen}
        projects={projects}
        currentProjectId={currentProjectId}
        onProjectSelect={handleProjectSelect}
        onProjectCreate={handleProjectCreate}
        onClose={() => setIsSidebarOpen(false)}
        isDark={isDark}
      />
      <div className="absolute top-4 left-4 z-50">
        <SidebarToggle 
          onClick={() => setIsSidebarOpen(!isSidebarOpen)} 
          isDark={isDark}
        />
      </div>
      <div className="flex-1 flex flex-col relative">
        <MoodBackground mood={currentMood} />
        <div className="absolute top-4 right-4 z-30">
          <button
            onClick={toggleTheme}
            className="p-2 rounded-lg bg-white/90 dark:bg-gray-800/90 shadow-lg hover:shadow-xl transition-all"
            aria-label="Toggle theme"
          >
            {isDark ? <Sun className="w-5 h-5 text-yellow-500" /> : <Moon className="w-5 h-5 text-gray-700" />}
          </button>
        </div>
        <div 
          className="flex-1 overflow-y-auto relative"
          ref={messagesContainerRef}
          onScroll={handleScroll}
        >
          {isLoadingHistory ? (
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="animate-pulse text-gray-500 dark:text-gray-400">Loading history...</div>
            </div>
          ) : (
            <>
              {isLoadingMore && (
                <div className="text-center py-4">
                  <span className="text-gray-500 dark:text-gray-400 text-sm">Loading more...</span>
                </div>
              )}
              {messages.slice().reverse().map((message) => (
                message.role === 'aside' ? (
                  <div key={message.id} className="flex justify-center my-2 px-4">
                    <div 
                      className={`
                        inline-block px-4 py-2 rounded-full text-center
                        bg-purple-100/80 dark:bg-purple-900/30 text-purple-700 dark:text-purple-300
                        italic text-sm max-w-xs
                      `}
                      style={{ 
                        fontSize: message.intensity 
                          ? `${0.8 + (message.intensity * 0.2)}rem` 
                          : '0.875rem'
                      }}
                    >
                      {message.content}
                    </div>
                  </div>
                ) : (
                  <MessageBubble 
                    key={message.id} 
                    message={message} 
                    isDark={isDark}
                    onArtifactClick={currentProjectId ? handleArtifactClick : undefined}
                  />
                )
              ))}
              {isThinking && (
                <ThinkingBubble visible={isThinking} isDark={isDark} />
              )}
            </>
          )}
          <div ref={messagesEndRef} />
        </div>
        {currentProjectId && (
          <div className="absolute bottom-20 right-4 z-20">
            <ArtifactToggle
              isOpen={showArtifacts}
              onClick={() => setShowArtifacts(!showArtifacts)}
              artifactCount={artifactCount}
              isDark={isDark}
            />
          </div>
        )}
        {connectionError && (
          <div className="relative z-10 px-4 py-2 bg-red-500/10 border-t border-red-500/20">
            <p className="text-sm text-red-600 dark:text-red-400 text-center">{connectionError}</p>
          </div>
        )}
        <ChatInput 
          onSend={handleSendMessage}
          disabled={false}
          isDark={isDark}
        />
      </div>
      {showArtifacts && currentProjectId && (
        <ArtifactViewer
          projectId={currentProjectId}
          isDark={isDark}
          onClose={() => {
            setShowArtifacts(false);
            setSelectedArtifactId(null);
          }}
          selectedArtifactId={selectedArtifactId || undefined}
          recentArtifacts={sessionArtifacts}
        />
      )}
    </div>
  );
};
