// src/components/CommitHistory.tsx
import React, { useState, useEffect } from 'react';
import { GitCommit, Clock, User, ChevronRight, Loader2, Copy, Check } from 'lucide-react';
import { API_BASE_URL } from '../services/config';

interface Commit {
  id: string;
  message: string;
  author: string;
  email: string;
  timestamp: number;
  parent_ids: string[];
}

interface CommitHistoryProps {
  projectId: string;
  attachmentId: string;
  isDark?: boolean;
  onCommitSelect?: (commitId: string) => void;
  limit?: number;
}

export const CommitHistory: React.FC<CommitHistoryProps> = ({
  projectId,
  attachmentId,
  isDark = false,
  onCommitSelect,
  limit = 20,
}) => {
  const [commits, setCommits] = useState<Commit[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedCommit, setSelectedCommit] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  useEffect(() => {
    loadCommits();
  }, [projectId, attachmentId, limit]);

  const loadCommits = async () => {
    try {
      setLoading(true);
      const response = await fetch(
        `${API_BASE_URL}/projects/${projectId}/git/${attachmentId}/commits?limit=${limit}`
      );
      
      if (!response.ok) {
        throw new Error('Failed to load commits');
      }
      
      const data = await response.json();
      setCommits(data.commits || []);
    } catch (error) {
      console.error('Failed to load commits:', error);
      setCommits([]);
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (timestamp: number) => {
    const date = new Date(timestamp * 1000);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    
    if (days === 0) {
      const hours = Math.floor(diff / (1000 * 60 * 60));
      if (hours === 0) {
        const minutes = Math.floor(diff / (1000 * 60));
        return minutes === 0 ? 'just now' : `${minutes} minute${minutes > 1 ? 's' : ''} ago`;
      }
      return `${hours} hour${hours > 1 ? 's' : ''} ago`;
    } else if (days === 1) {
      return 'yesterday';
    } else if (days < 7) {
      return `${days} days ago`;
    } else if (days < 30) {
      const weeks = Math.floor(days / 7);
      return `${weeks} week${weeks > 1 ? 's' : ''} ago`;
    } else if (days < 365) {
      const months = Math.floor(days / 30);
      return `${months} month${months > 1 ? 's' : ''} ago`;
    } else {
      return date.toLocaleDateString();
    }
  };

  const copyCommitId = async (commitId: string) => {
    try {
      await navigator.clipboard.writeText(commitId);
      setCopiedId(commitId);
      setTimeout(() => setCopiedId(null), 2000);
    } catch (error) {
      console.error('Failed to copy commit ID:', error);
    }
  };

  const handleCommitClick = (commit: Commit) => {
    setSelectedCommit(commit.id === selectedCommit ? null : commit.id);
    onCommitSelect?.(commit.id);
  };

  if (loading) {
    return (
      <div className={`flex items-center justify-center p-8 ${isDark ? 'bg-gray-800' : 'bg-white'}`}>
        <div className="flex items-center gap-2 text-sm text-gray-500">
          <Loader2 className="w-4 h-4 animate-spin" />
          Loading commit history...
        </div>
      </div>
    );
  }

  if (commits.length === 0) {
    return (
      <div className={`${isDark ? 'bg-gray-800' : 'bg-white'}`}>
        <div className={`px-4 py-3 border-b ${isDark ? 'border-gray-700' : 'border-gray-200'}`}>
          <h3 className={`text-sm font-medium flex items-center gap-2 ${
            isDark ? 'text-gray-200' : 'text-gray-700'
          }`}>
            <GitCommit className="w-4 h-4" />
            Commit History
          </h3>
        </div>
        <div className={`p-8 text-center text-sm ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>
          No commits found in this repository
        </div>
      </div>
    );
  }

  return (
    <div className={`${isDark ? 'bg-gray-800' : 'bg-white'} h-full flex flex-col`}>
      <div className={`px-4 py-3 border-b ${isDark ? 'border-gray-700' : 'border-gray-200'}`}>
        <h3 className={`text-sm font-medium flex items-center gap-2 ${
          isDark ? 'text-gray-200' : 'text-gray-700'
        }`}>
          <GitCommit className="w-4 h-4" />
          Commit History
          <span className={`text-xs px-2 py-0.5 rounded-full ${
            isDark ? 'bg-gray-700 text-gray-400' : 'bg-gray-100 text-gray-600'
          }`}>
            {commits.length}
          </span>
        </h3>
      </div>
      
      <div className={`flex-1 overflow-y-auto divide-y ${
        isDark ? 'divide-gray-700' : 'divide-gray-200'
      }`}>
        {commits.map((commit) => (
          <button
            key={commit.id}
            onClick={() => handleCommitClick(commit)}
            className={`w-full px-4 py-3 text-left transition-colors ${
              selectedCommit === commit.id
                ? isDark
                  ? 'bg-blue-900/20'
                  : 'bg-blue-50'
                : isDark
                  ? 'hover:bg-gray-700'
                  : 'hover:bg-gray-50'
            }`}
          >
            <div className="flex items-start justify-between gap-3">
              <div className="flex-1 min-w-0">
                <p className={`text-sm font-medium ${
                  isDark ? 'text-gray-200' : 'text-gray-900'
                } line-clamp-2`}>
                  {commit.message}
                </p>
                <div className={`flex items-center gap-3 mt-1 text-xs ${
                  isDark ? 'text-gray-400' : 'text-gray-500'
                }`}>
                  <span className="flex items-center gap-1">
                    <User className="w-3 h-3" />
                    <span className="truncate max-w-[150px]">{commit.author}</span>
                  </span>
                  <span className="flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {formatDate(commit.timestamp)}
                  </span>
                </div>
              </div>
              
              <div className="flex items-center gap-1">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    copyCommitId(commit.id);
                  }}
                  className={`group relative px-2 py-1 rounded text-xs font-mono transition-colors ${
                    isDark 
                      ? 'bg-gray-700 text-gray-400 hover:bg-gray-600' 
                      : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  }`}
                  title="Copy commit ID"
                >
                  {commit.id.substring(0, 7)}
                  <div className={`absolute -top-1 -right-1 transition-opacity ${
                    copiedId === commit.id ? 'opacity-100' : 'opacity-0'
                  }`}>
                    <Check className="w-3 h-3 text-green-500" />
                  </div>
                </button>
                <ChevronRight className={`w-4 h-4 transition-transform ${
                  selectedCommit === commit.id ? 'rotate-90' : ''
                } ${isDark ? 'text-gray-500' : 'text-gray-400'}`} />
              </div>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
};
