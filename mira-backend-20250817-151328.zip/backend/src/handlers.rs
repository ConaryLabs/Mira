// src/handlers.rs
// Final version with borrow checker fixes and cleanup

use axum::{
    extract::{Query, State, Json},
    response::IntoResponse,
};
use serde::{Deserialize, Serialize};
use std::sync::Arc;
use tracing::{error, info};
use futures::StreamExt;

use crate::state::AppState;
use crate::services::chat::ChatResponse;
use crate::api::two_phase::{get_metadata, get_content_stream};
use crate::llm::streaming::StreamEvent;
use crate::persona::PersonaOverlay;
use crate::memory::recall::{RecallContext, MemoryEntry};

// ============================================================================
// Request/Response Types
// ============================================================================

#[derive(Debug, Deserialize)]
pub struct ChatRequest {
    pub session_id: String,
    pub message: String,
}

#[derive(Debug, Serialize)]
pub struct ChatResponseWrapper {
    pub success: bool,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub data: Option<ChatResponse>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub error: Option<String>,
}

#[derive(Debug, Deserialize)]
pub struct ChatQueryParams {
    #[serde(default)]
    pub structured: bool,
}

#[derive(Debug, Serialize)]
pub struct HealthResponse {
    pub status: String,
    pub version: String,
}

#[derive(Debug, Deserialize)]
pub struct HistoryRequest {
    pub session_id: String,
}

#[derive(Debug, Serialize)]
pub struct HistoryResponse {
    pub success: bool,
    pub messages: Vec<MessageEntry>,
}

#[derive(Debug, Serialize)]
pub struct MessageEntry {
    pub role: String,
    pub content: String,
}

// ============================================================================
// Handlers
// ============================================================================

pub async fn health_handler() -> impl IntoResponse {
    Json(HealthResponse {
        status: "healthy".to_string(),
        version: env!("CARGO_PKG_VERSION").to_string(),
    })
}

pub async fn chat_handler(
    State(state): State<Arc<AppState>>,
    Query(_params): Query<ChatQueryParams>,
    Json(payload): Json<ChatRequest>,
) -> impl IntoResponse {
    info!("📨 Chat request for session: {}", payload.session_id);
    
    let persona = PersonaOverlay::mira();
    let context = match state.memory_service
        .build_context(&payload.session_id, &payload.message)
        .await 
    {
        Ok(ctx) => ctx,
        Err(e) => {
            error!("Failed to build context: {}", e);
            RecallContext::default()
        }
    };
    
    // PHASE 1: Get metadata
    let metadata = match get_metadata(
        &state.llm_client,
        &payload.message,
        &persona,
        &context,
    ).await {
        Ok(m) => m,
        Err(e) => {
            return Json(ChatResponseWrapper {
                success: false,
                data: None,
                error: Some(format!("Failed to get metadata: {}", e)),
            });
        }
    };
    
    // PHASE 2: Get full content - pass cloned strings to avoid borrow issues
    let mut content_stream = match get_content_stream(
        &state.llm_client,
        &payload.message,
        &persona,
        &context,
        &metadata.mood.clone(),     // Clone the strings
        &metadata.intent.clone(),   // Clone here too
    ).await {
        Ok(s) => s,
        Err(e) => {
            return Json(ChatResponseWrapper {
                success: false,
                data: None,
                error: Some(format!("Failed to get content: {}", e)),
            });
        }
    };
    
    let mut full_content = String::new();
    while let Some(event) = content_stream.next().await {
        if let Ok(StreamEvent::Delta(chunk)) = event {
            full_content.push_str(&chunk);
        }
    }
    
    // Now we can move from metadata freely
    let complete_output = if metadata.output.is_empty() {
        full_content
    } else {
        format!("{}\n\n{}", metadata.output, full_content)
    };
    
    let response = ChatResponse {
        output: complete_output,
        persona: "mira".to_string(),
        mood: metadata.mood,           // Can move now!
        salience: metadata.salience,
        summary: metadata.summary,
        memory_type: metadata.memory_type,
        tags: metadata.tags,
        intent: metadata.intent,
        monologue: metadata.monologue,
        reasoning_summary: metadata.reasoning_summary,
    };
    
    // Save to memory
    let _ = state.memory_service.save_assistant_response(
        &payload.session_id,
        &response,
    ).await;
    
    Json(ChatResponseWrapper {
        success: true,
        data: Some(response),
        error: None,
    })
}

pub async fn history_handler(
    State(state): State<Arc<AppState>>,
    Json(payload): Json<HistoryRequest>,
) -> impl IntoResponse {
    info!("📜 History request for session: {}", payload.session_id);

    // Use the memory service's actual method
    match state.memory_service
        .get_recent_context(&payload.session_id, 50)
        .await
    {
        Ok(messages) => {
            let entries: Vec<MessageEntry> = messages
                .into_iter()
                .map(|msg| MessageEntry {
                    role: msg.role,
                    content: msg.content,
                })
                .collect();

            Json(HistoryResponse {
                success: true,
                messages: entries,
            })
        }
        Err(e) => {
            error!("Failed to get history: {}", e);
            Json(HistoryResponse {
                success: false,
                messages: vec![],
            })
        }
    }
}
