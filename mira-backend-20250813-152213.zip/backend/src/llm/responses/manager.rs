// src/llm/responses/manager.rs
use std::sync::Arc;

use anyhow::Result;
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use tracing::{debug, error, info};

use crate::llm::client::OpenAIClient;

#[derive(Clone)]
pub struct ResponsesManager {
    client: Arc<OpenAIClient>,
    responses_id: Option<String>,
}

impl ResponsesManager {
    pub fn new(client: Arc<OpenAIClient>) -> Self {
        Self { client, responses_id: None }
    }

    pub async fn create_response(
        &self,
        model: &str,
        messages: Vec<Value>,
        instructions: Option<String>,
        response_format: Option<Value>,  // This is still here for backward compatibility
        parameters: Option<Value>,       // This contains verbosity, reasoning_effort, etc.
    ) -> Result<ResponseObject> {
        let mut body = json!({ "model": model, "input": messages });
        
        if let Some(ref instr) = instructions { 
            body["instructions"] = Value::String(instr.clone()); 
        }
        
        // Extract parameters and merge them appropriately
        // Ensure clean values by trimming and validating
        let mut verbosity = "medium";
        let mut reasoning_effort = "medium";
        let mut max_output_tokens = 128000;
        
        if let Some(params) = &parameters {
            if let Some(v) = params.get("verbosity").and_then(|v| v.as_str()) {
                // Validate verbosity value
                verbosity = match v.trim() {
                    "low" => "low",
                    "high" => "high",
                    _ => "medium", // Default to medium for any other value
                };
            }
            if let Some(r) = params.get("reasoning_effort").and_then(|r| r.as_str()) {
                // Validate reasoning effort value
                reasoning_effort = match r.trim() {
                    "minimal" | "low" => "low",
                    "high" => "high",
                    _ => "medium", // Default to medium
                };
            }
            if let Some(m) = params.get("max_output_tokens") {
                if let Some(num) = m.as_u64() {
                    max_output_tokens = num as usize;
                } else if let Some(num) = m.as_i64() {
                    max_output_tokens = num as usize;
                }
            }
        }
        
        // Build the text object with format and verbosity
        let mut text_obj = json!({
            "verbosity": verbosity
        });
        
        // Add format if structured response requested
        if let Some(fmt) = response_format {
            if fmt.get("type").and_then(|t| t.as_str()) == Some("json_object") {
                // Format should be an object with type field
                text_obj["format"] = json!({
                    "type": "json_object"
                });
            }
        }
        
        body["text"] = text_obj.clone();
        
        // Add reasoning at the top level
        body["reasoning"] = json!({
            "effort": reasoning_effort
        });
        
        // Add max_output_tokens at the top level
        body["max_output_tokens"] = json!(max_output_tokens);

        // DEBUG: Log the request body
        info!("🔍 Sending request to OpenAI:");
        info!("   Model: {}", model);
        info!("   Verbosity: {}", verbosity);
        info!("   Reasoning effort: {}", reasoning_effort);
        info!("   Max output tokens: {}", max_output_tokens);
        info!("   Has instructions: {}", instructions.is_some());
        info!("   Has format: {}", text_obj.get("format").is_some());
        info!("   Input messages count: {}", messages.len());
        
        // Log first message to verify JSON is mentioned
        if let Some(first_msg) = messages.first() {
            debug!("   First message: {}", first_msg.to_string());
        }
        
        // Log the full request body for debugging
        debug!("📤 Full request body: {}", serde_json::to_string_pretty(&body).unwrap_or_default());

        let v = match self.client.post_response(body).await {
            Ok(response) => {
                info!("✅ Got response from OpenAI");
                response
            }
            Err(e) => {
                error!("❌ OpenAI API error: {:?}", e);
                return Err(e);
            }
        };

        // Extract the output text
        if let Some(output_val) = v.get("output").cloned() {
            let text = extract_text_from_output(&output_val);
            info!("📝 Extracted text from output (length: {} chars)", text.len());
            return Ok(ResponseObject { raw: v, text });
        }

        // Fallback to old format
        let text = v
            .pointer("/choices/0/message/content")
            .and_then(|c| c.as_array())
            .map(|arr| {
                arr.iter()
                    .filter_map(|part| {
                        if part.get("type").and_then(|t| t.as_str()) == Some("output_text") {
                            part.get("text").and_then(|t| t.as_str()).map(|s| s.to_string())
                        } else { None }
                    })
                    .collect::<Vec<_>>()
                    .join("")
            })
            .unwrap_or_default();

        info!("📝 Extracted text from fallback format (length: {} chars)", text.len());
        Ok(ResponseObject { raw: v, text })
    }

    pub fn get_responses_id(&self) -> Option<&str> {
        self.responses_id.as_deref()
    }
}

fn extract_text_from_output(output: &Value) -> String {
    if let Some(arr) = output.as_array() {
        let mut s = String::new();
        for item in arr {
            // Try different possible output formats
            if item.get("type").and_then(|t| t.as_str()) == Some("output_text") {
                if let Some(t) = item.get("text").and_then(|t| t.as_str()) {
                    s.push_str(t);
                }
            } else if item.get("type").and_then(|t| t.as_str()) == Some("message") {
                // Sometimes the output is wrapped in a message type
                if let Some(content) = item.get("content").and_then(|c| c.as_array()) {
                    for content_item in content {
                        if content_item.get("type").and_then(|t| t.as_str()) == Some("text") {
                            if let Some(t) = content_item.get("text").and_then(|t| t.as_str()) {
                                s.push_str(t);
                            }
                        }
                    }
                }
            }
        }
        return s;
    }
    String::new()
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ResponseObject {
    pub text: String,
    #[serde(skip)]
    pub raw: Value,
}
