// src/services/chat.rs

use crate::llm::client::OpenAIClient;
use crate::llm::persona::PersonaOverlay;
use crate::llm::schema::{ChatResponse, ChatRequest};
use anyhow::{Result, Context};
use serde_json::json;
use reqwest::Method;
use std::sync::Arc;

#[derive(Clone)]
pub struct ChatService {
    pub llm_client: Arc<OpenAIClient>,
}

impl ChatService {
    pub fn new(llm_client: Arc<OpenAIClient>) -> Self {
        Self { llm_client }
    }

    /// Core chat method — runs user content through the LLM and returns a structured response.
    pub async fn process_message(
        &self,
        session_id: &str,
        content: &str,
        persona: &PersonaOverlay,
        project_id: Option<&str>,
    ) -> Result<ChatResponse> {
        // Construct your full LLM prompt (add persona/context if needed)
        let prompt = format!(
            "{}\n\n[Persona: {:?}]\n[Session ID: {}]\n[Project: {:?}]",
            content, persona, session_id, project_id
        );

        let payload = json!({
            "model": "gpt-4o", // or your default model
            "messages": [
                { "role": "system", "content": "You are Mira. Be witty, warm, and real. Respond like a human friend, not a bot." },
                { "role": "user", "content": prompt }
            ],
            "max_tokens": 2048,
            "temperature": 0.85,
            "stream": false,
        });

        let res = self.llm_client
            .request(Method::POST, "chat/completions")
            .json(&payload)
            .send()
            .await
            .context("Failed to call OpenAI chat API")?
            .error_for_status()
            .context("Non-2xx from OpenAI chat/completions")?
            .json::<serde_json::Value>()
            .await
            .context("Failed to parse OpenAI chat API response")?;

        let output = res["choices"][0]["message"]["content"]
            .as_str()
            .unwrap_or("")
            .to_string();

        // In a real system, you’d extract mood, intent, salience, etc. from the LLM output or metadata
        Ok(ChatResponse {
            output,
            persona: Some(persona.to_string()),
            mood: None,
            salience: 5,
            tags: vec![],
            memory_type: None,
            intent: None,
            summary: None,
            monologue: None,
        })
    }

    /// LLM-powered helper: Use GPT-4o to route a document upload.
    pub async fn run_routing_inference(
        &self,
        system_prompt: &str,
        user_prompt: &str,
    ) -> Result<String> {
        let payload = json!({
            "model": "gpt-4.1",
            "messages": [
                { "role": "system", "content": system_prompt },
                { "role": "user", "content": user_prompt }
            ],
            "max_tokens": 8,
            "temperature": 0.0,
            "stream": false,
        });

        let res = self.llm_client
            .request(Method::POST, "chat/completions")
            .json(&payload)
            .send()
            .await
            .context("Failed to call OpenAI for document routing")?
            .error_for_status()
            .context("Non-2xx from OpenAI for routing")?
            .json::<serde_json::Value>()
            .await
            .context("Failed to parse OpenAI routing response")?;

        let text = res["choices"][0]["message"]["content"]
            .as_str()
            .unwrap_or("")
            .to_string();

        Ok(text)
    }

    /// Example: Embedding helper (if needed for hybrid memory context)
    pub async fn get_embedding(&self, content: &str) -> Result<Vec<f32>> {
        let payload = json!({
            "input": content,
            "model": "text-embedding-3-large"
        });

        let res = self.llm_client
            .request(Method::POST, "embeddings")
            .json(&payload)
            .send()
            .await?
            .error_for_status()?
            .json::<serde_json::Value>()
            .await?;

        // Parse embedding result — may vary by model/version
        let embedding = res["data"][0]["embedding"]
            .as_array()
            .ok_or_else(|| anyhow::anyhow!("Malformed embedding response"))?
            .iter()
            .map(|v| v.as_f64().unwrap_or(0.0) as f32)
            .collect();

        Ok(embedding)
    }
}
