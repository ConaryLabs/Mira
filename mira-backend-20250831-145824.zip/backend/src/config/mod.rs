// src/config/mod.rs

use lazy_static::lazy_static;
use serde::{Deserialize, Serialize};
use std::str::FromStr;

lazy_static! {
    pub static ref CONFIG: MiraConfig = MiraConfig::from_env();
}

/// Main configuration structure for Mira
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MiraConfig {
    // ── Core LLM Configuration ──
    pub openai_api_key: Option<String>,
    pub openai_base_url: String,
    pub model: String,
    pub verbosity: String,
    pub reasoning_effort: String,
    pub max_output_tokens: usize,
    pub debug_logging: bool,
    pub intent_model: String,

    // ── Database & Storage Configuration ──
    pub database_url: String,
    pub sqlite_max_connections: usize,

    // ── Session & User Configuration ──
    pub session_id: String,
    pub default_persona: String,

    // ── Memory & History Configuration ──
    pub history_message_cap: usize,
    pub history_token_limit: usize,
    pub max_retrieval_tokens: usize,
    pub ws_history_cap: usize,
    pub ws_vector_search_k: usize,
    pub ws_heartbeat_interval: u64,
    pub ws_connection_timeout: u64,
    pub ws_receive_timeout: u64,
    pub history_default_limit: usize,
    pub history_max_limit: usize,
    pub context_recent_messages: usize,
    pub context_semantic_matches: usize,

    // ── Memory Service Configuration ──
    pub always_embed_user: bool,
    pub always_embed_assistant: bool,
    pub embed_min_chars: usize,
    pub dedup_sim_threshold: f32,
    pub salience_min_for_embed: u8,
    pub rollup_every: usize,
    pub min_salience_for_qdrant: f32,
    pub min_salience_for_storage: f32,

    // ── Summarization Configuration ──
    pub enable_summarization: bool,
    pub summary_chunk_size: usize,
    pub summary_token_limit: usize,
    pub summary_output_tokens: usize,
    pub summarize_after_messages: usize,

    // ── Vector Search Configuration ──
    pub max_vector_results: usize,
    pub enable_vector_search: bool,

    // ── Tool Configuration ──
    pub enable_chat_tools: bool,
    pub enable_web_search: bool,
    pub enable_code_interpreter: bool,
    pub enable_file_search: bool,
    pub enable_image_generation: bool,
    pub web_search_max_results: usize,
    pub web_search_timeout: u64,
    pub code_interpreter_timeout: u64,
    pub code_interpreter_max_output: usize,
    pub file_search_max_files: usize,
    pub file_search_chunk_size: usize,
    pub image_generation_size: String,
    pub image_generation_quality: String,
    pub image_generation_style: String,

    // ── Qdrant Configuration ──
    pub qdrant_url: String,
    pub qdrant_collection: String,
    pub qdrant_embedding_dim: usize,
    pub qdrant_test_url: String,
    pub qdrant_test_collection: String,

    // ── Git Configuration ──
    pub git_repos_dir: String,
    pub git_cache_dir: String,
    pub git_max_file_size: usize,

    // ── Import Configuration ──
    pub import_sqlite: String,
    pub import_qdrant_url: String,
    pub import_qdrant_collection: String,

    // ── Persona Configuration ──
    pub persona: String,
    pub persona_decay_timeout: u64,
    pub session_stale_timeout: u64,

    // ── Server Configuration ──
    pub host: String,
    pub port: u16,
    pub cors_origin: String,
    pub cors_credentials: bool,
    pub rate_limit_chat: usize,
    pub rate_limit_ws: usize,
    pub rate_limit_search: usize,
    pub rate_limit_git: usize,
    pub max_concurrent_embeddings: usize,

    // ── Timeouts (in seconds)
    pub openai_timeout: u64,
    pub qdrant_timeout: u64,
    pub database_timeout: u64,

    // ── Logging Configuration
    pub log_level: String,
    pub log_format: String,
    pub trace_sql: bool,

    // ═══════════════════════════════════════════════════════════════
    // ─── PHASE 0: MINIMAL ROBUST MEMORY FEATURE GATES ─────────────
    // ═══════════════════════════════════════════════════════════════

    /// Master flag to enable all new robust memory behaviors (OFF by default)
    pub aggressive_metadata_enabled: bool,

    /// Comma-separated list of embedding heads (only used when master flag is ON)
    pub embed_heads: String,

    /// Enable rolling summaries every 10 messages (only used when master flag is ON)
    pub summary_rolling_10: bool,

    /// Enable rolling summaries every 100 messages (only used when master flag is ON)
    pub summary_rolling_100: bool,

    /// ── Phase 4: Additional rolling summary flags ──
    /// Enable manual snapshot summaries via API
    pub summary_phase_snapshots: bool,

    /// Use rolling summaries in context building (when available)
    pub use_rolling_summaries_in_context: bool,

    /// Maximum age (in hours) for rolling summaries to be considered in context
    pub rolling_summary_max_age_hours: u32,

    /// Minimum message gap before creating new rolling summary
    pub rolling_summary_min_gap: usize,

    // ═══════════════════════════════════════════════════════════════
    // ─── PHASE 2: CHUNKING PARAMETERS FOR EMBEDDING HEADS ──────────
    // ═══════════════════════════════════════════════════════════════
    pub embed_semantic_chunk: usize,
    pub embed_semantic_overlap: usize,
    pub embed_code_chunk: usize,
    pub embed_code_overlap: usize,
    pub embed_summary_chunk: usize,
    pub embed_summary_overlap: usize,
}

// Helper function - unchanged
fn env_var_or<T>(key: &str, default: T) -> T
where
    T: FromStr,
{
    match std::env::var(key) {
        Ok(val) => {
            let clean_val = val.split('#').next().unwrap_or("").trim();
            match clean_val.parse::<T>() {
                Ok(parsed) => {
                    eprintln!("Config: {} = {} (from environment)", key, clean_val);
                    parsed
                }
                Err(_) => {
                    eprintln!(
                        "Config: {} = '{}' (parse failed, using default)",
                        key, val
                    );
                    default
                }
            }
        }
        Err(_) => default,
    }
}

impl MiraConfig {
    pub fn from_env() -> Self {
        if dotenv::dotenv().is_err() {
            eprintln!("Warning: .env file not found. Using environment variables and defaults.");
        }

        Self {
            // ── Core LLM Configuration ──
            openai_api_key: std::env::var("OPENAI_API_KEY").ok(),
            openai_base_url: env_var_or("OPENAI_BASE_URL", "https://api.openai.com".to_string()),
            model: env_var_or("MIRA_MODEL", "gpt-5".to_string()),
            verbosity: env_var_or("MIRA_VERBOSITY", "high".to_string()),
            reasoning_effort: env_var_or("MIRA_REASONING_EFFORT", "high".to_string()),
            max_output_tokens: env_var_or("MIRA_MAX_OUTPUT_TOKENS", 128000),
            debug_logging: env_var_or("MIRA_DEBUG_LOGGING", false),
            intent_model: env_var_or("MIRA_INTENT_MODEL", "gpt-5".to_string()),

            // ── Database & Storage Configuration ──
            database_url: env_var_or("DATABASE_URL", "sqlite:./mira.db".to_string()),
            sqlite_max_connections: env_var_or("SQLITE_MAX_CONNECTIONS", 10),

            // ── Session & User Configuration ──
            session_id: env_var_or("MIRA_SESSION_ID", "peter-eternal".to_string()),
            default_persona: env_var_or("MIRA_DEFAULT_PERSONA", "default".to_string()),

            // ── Memory & History Configuration ──
            history_message_cap: env_var_or("MIRA_HISTORY_MESSAGE_CAP", 50),
            history_token_limit: env_var_or("MIRA_HISTORY_TOKEN_LIMIT", 65536),
            max_retrieval_tokens: env_var_or("MIRA_MAX_RETRIEVAL_TOKENS", 8192),
            ws_history_cap: env_var_or("MIRA_WS_HISTORY_CAP", 100),
            ws_vector_search_k: env_var_or("MIRA_WS_VECTOR_SEARCH_K", 15),
            ws_heartbeat_interval: env_var_or("MIRA_WS_HEARTBEAT_INTERVAL", 30),
            ws_connection_timeout: env_var_or("MIRA_WS_CONNECTION_TIMEOUT", 300),
            ws_receive_timeout: env_var_or("MIRA_WS_RECEIVE_TIMEOUT", 60),
            history_default_limit: env_var_or("MIRA_HISTORY_DEFAULT_LIMIT", 30),
            history_max_limit: env_var_or("MIRA_HISTORY_MAX_LIMIT", 100),
            context_recent_messages: env_var_or("MIRA_CONTEXT_RECENT_MESSAGES", 30),
            context_semantic_matches: env_var_or("MIRA_CONTEXT_SEMANTIC_MATCHES", 15),

            // ── Memory Service Configuration ──
            always_embed_user: env_var_or("MEM_ALWAYS_EMBED_USER", true),
            always_embed_assistant: env_var_or("MEM_ALWAYS_EMBED_ASSISTANT", true),
            embed_min_chars: env_var_or("MEM_EMBED_MIN_CHARS", 6),
            dedup_sim_threshold: env_var_or("MEM_DEDUP_SIM_THRESHOLD", 0.97),
            salience_min_for_embed: env_var_or("MEM_SALIENCE_MIN_FOR_EMBED", 6),
            rollup_every: env_var_or("MEM_ROLLUP_EVERY", 50),
            min_salience_for_qdrant: env_var_or("MIRA_MIN_SALIENCE_FOR_QDRANT", 3.0),
            min_salience_for_storage: env_var_or("MIRA_MIN_SALIENCE_FOR_STORAGE", 5.0),

            // ── Summarization Configuration ──
            enable_summarization: env_var_or("MIRA_ENABLE_SUMMARIZATION", true),
            summary_chunk_size: env_var_or("MIRA_SUMMARY_CHUNK_SIZE", 10),
            summary_token_limit: env_var_or("MIRA_SUMMARY_TOKEN_LIMIT", 32000),
            summary_output_tokens: env_var_or("MIRA_SUMMARY_OUTPUT_TOKENS", 2048),
            summarize_after_messages: env_var_or("MIRA_SUMMARIZE_AFTER_MESSAGES", 12),

            // ── Vector Search Configuration ──
            max_vector_results: env_var_or("MIRA_MAX_VECTOR_RESULTS", 5),
            enable_vector_search: env_var_or("MIRA_ENABLE_VECTOR_SEARCH", true),

            // ── Tool Configuration ──
            enable_chat_tools: env_var_or("ENABLE_CHAT_TOOLS", true),
            enable_web_search: env_var_or("ENABLE_WEB_SEARCH", true),
            enable_code_interpreter: env_var_or("ENABLE_CODE_INTERPRETER", true),
            enable_file_search: env_var_or("ENABLE_FILE_SEARCH", true),
            enable_image_generation: env_var_or("ENABLE_IMAGE_GENERATION", true),
            web_search_max_results: env_var_or("WEB_SEARCH_MAX_RESULTS", 10),
            web_search_timeout: env_var_or("WEB_SEARCH_TIMEOUT", 30),
            code_interpreter_timeout: env_var_or("CODE_INTERPRETER_TIMEOUT", 60),
            code_interpreter_max_output: env_var_or("CODE_INTERPRETER_MAX_OUTPUT", 10000),
            file_search_max_files: env_var_or("FILE_SEARCH_MAX_FILES", 20),
            file_search_chunk_size: env_var_or("FILE_SEARCH_CHUNK_SIZE", 1000),
            image_generation_size: env_var_or("IMAGE_GENERATION_SIZE", "1024x1024".to_string()),
            image_generation_quality: env_var_or(
                "IMAGE_GENERATION_QUALITY",
                "standard".to_string(),
            ),
            image_generation_style: env_var_or("IMAGE_GENERATION_STYLE", "vivid".to_string()),

            // ── Qdrant Configuration ──
            qdrant_url: env_var_or("QDRANT_URL", "http://localhost:6333".to_string()),
            qdrant_collection: env_var_or("QDRANT_COLLECTION", "mira-memory".to_string()),
            qdrant_embedding_dim: env_var_or("QDRANT_EMBEDDING_DIM", 3072),
            qdrant_test_url: env_var_or("QDRANT_TEST_URL", "http://localhost:6334".to_string()),
            qdrant_test_collection: env_var_or("QDRANT_TEST_COLLECTION", "mira-test".to_string()),

            // ── Git Configuration ──
            git_repos_dir: env_var_or("GIT_REPOS_DIR", "./repos".to_string()),
            git_cache_dir: env_var_or("MIRA_GIT_CACHE_DIR", "/tmp/mira-git-cache".to_string()),
            git_max_file_size: env_var_or("MIRA_GIT_MAX_FILE_SIZE", 10485760),

            // ── Import Configuration ──
            import_sqlite: env_var_or("MIRA_IMPORT_SQLITE", "mira.sqlite".to_string()),
            import_qdrant_url: env_var_or(
                "MIRA_IMPORT_QDRANT_URL",
                "http://localhost:6333".to_string(),
            ),
            import_qdrant_collection: env_var_or(
                "MIRA_IMPORT_QDRANT_COLLECTION",
                "mira_memories".to_string(),
            ),

            // ── Persona Configuration ──
            persona: env_var_or("MIRA_PERSONA", "Default".to_string()),
            persona_decay_timeout: env_var_or("MIRA_PERSONA_DECAY_TIMEOUT", 60),
            session_stale_timeout: env_var_or("MIRA_SESSION_STALE_TIMEOUT", 30),

            // ── Server Configuration ──
            host: env_var_or("MIRA_HOST", "0.0.0.0".to_string()),
            port: env_var_or("MIRA_PORT", 3001),
            cors_origin: env_var_or("MIRA_CORS_ORIGIN", "http://localhost:3000".to_string()),
            cors_credentials: env_var_or("MIRA_CORS_CREDENTIALS", true),
            rate_limit_chat: env_var_or("MIRA_RATE_LIMIT_CHAT", 60),
            rate_limit_ws: env_var_or("MIRA_RATE_LIMIT_WS", 100),
            rate_limit_search: env_var_or("MIRA_RATE_LIMIT_SEARCH", 30),
            rate_limit_git: env_var_or("MIRA_RATE_LIMIT_GIT", 10),
            max_concurrent_embeddings: env_var_or("MIRA_MAX_CONCURRENT_EMBEDDINGS", 10),

            // ── Timeouts (in seconds)
            openai_timeout: env_var_or("OPENAI_TIMEOUT", 300),
            qdrant_timeout: env_var_or("QDRANT_TIMEOUT", 30),
            database_timeout: env_var_or("DATABASE_TIMEOUT", 10),

            // ── Logging Configuration
            log_level: env_var_or("MIRA_LOG_LEVEL", "info".to_string()),
            log_format: env_var_or("MIRA_LOG_FORMAT", "pretty".to_string()),
            trace_sql: env_var_or("MIRA_TRACE_SQL", false),

            // ═══════════════════════════════════════════════════════════════
            // ─── PHASE 0: MINIMAL ROBUST MEMORY FEATURE GATES ─────────────
            // ═══════════════════════════════════════════════════════════════
            aggressive_metadata_enabled: env_var_or("MIRA_AGGRESSIVE_METADATA_ENABLED", false),
            embed_heads: env_var_or("MIRA_EMBED_HEADS", "semantic,code,summary".to_string()),
            summary_rolling_10: env_var_or("MIRA_SUMMARY_ROLLING_10", true),
            summary_rolling_100: env_var_or("MIRA_SUMMARY_ROLLING_100", true),

            // ── Phase 4: Additional rolling summary flags ──
            summary_phase_snapshots: env_var_or("MIRA_SUMMARY_PHASE_SNAPSHOTS", true),
            use_rolling_summaries_in_context: env_var_or(
                "MIRA_USE_ROLLING_SUMMARIES_IN_CONTEXT",
                true,
            ),
            rolling_summary_max_age_hours: env_var_or("MIRA_ROLLING_SUMMARY_MAX_AGE_HOURS", 168), // 1 week
            rolling_summary_min_gap: env_var_or("MIRA_ROLLING_SUMMARY_MIN_GAP", 3),

            // ═══════════════════════════════════════════════════════════════
            // ─── PHASE 2: CHUNKING PARAMETERS FOR EMBEDDING HEADS ──────────
            // ═══════════════════════════════════════════════════════════════
            embed_semantic_chunk: env_var_or("MIRA_EMBED_SEMANTIC_CHUNK", 300),
            embed_semantic_overlap: env_var_or("MIRA_EMBED_SEMANTIC_OVERLAP", 100),
            embed_code_chunk: env_var_or("MIRA_EMBED_CODE_CHUNK", 256),
            embed_code_overlap: env_var_or("MIRA_EMBED_CODE_OVERLAP", 64),
            embed_summary_chunk: env_var_or("MIRA_EMBED_SUMMARY_CHUNK", 600),
            embed_summary_overlap: env_var_or("MIRA_EMBED_SUMMARY_OVERLAP", 200),
        }
    }

    /// Get the bind address for the server.
    pub fn bind_address(&self) -> String {
        format!("{}:{}", self.host, self.port)
    }

    /// ── Phase 4: Convenience methods for rolling summaries ──

    /// Check if robust memory features are enabled
    pub fn is_robust_memory_enabled(&self) -> bool {
        self.aggressive_metadata_enabled
    }

    /// Check if rolling summaries are enabled (any type)
    pub fn rolling_summaries_enabled(&self) -> bool {
        self.aggressive_metadata_enabled && (self.summary_rolling_10 || self.summary_rolling_100)
    }

    /// Check if 10-message rolling summaries are enabled
    pub fn rolling_10_enabled(&self) -> bool {
        self.aggressive_metadata_enabled && self.summary_rolling_10
    }

    /// Check if 100-message rolling summaries are enabled
    pub fn rolling_100_enabled(&self) -> bool {
        self.aggressive_metadata_enabled && self.summary_rolling_100
    }

    /// Check if snapshot summaries are enabled
    pub fn snapshot_summaries_enabled(&self) -> bool {
        self.aggressive_metadata_enabled && self.summary_phase_snapshots
    }

    /// Check if rolling summaries should be used in context building
    pub fn should_use_rolling_summaries_in_context(&self) -> bool {
        self.aggressive_metadata_enabled
            && self.use_rolling_summaries_in_context
            && (self.summary_rolling_10 || self.summary_rolling_100)
    }

    /// Get the list of embedding heads to use
    pub fn get_embedding_heads(&self) -> Vec<String> {
        if self.aggressive_metadata_enabled {
            self.embed_heads
                .split(',')
                .map(|s| s.trim().to_string())
                .filter(|s| !s.is_empty())
                .collect()
        } else {
            // Fallback to single semantic head when robust memory is disabled
            vec!["semantic".to_string()]
        }
    }

    /// Get chunk size for a specific embedding head
    pub fn get_chunk_size_for_head(&self, head: &str) -> usize {
        match head {
            "semantic" => self.embed_semantic_chunk,
            "code" => self.embed_code_chunk,
            "summary" => self.embed_summary_chunk,
            _ => self.embed_semantic_chunk, // Default to semantic
        }
    }

    /// Get chunk overlap for a specific embedding head
    pub fn get_chunk_overlap_for_head(&self, head: &str) -> usize {
        match head {
            "semantic" => self.embed_semantic_overlap,
            "code" => self.embed_code_overlap,
            "summary" => self.embed_summary_overlap,
            _ => self.embed_semantic_overlap, // Default to semantic
        }
    }

    /// Get rolling summary configuration summary for debugging
    pub fn get_rolling_summary_config(&self) -> RollingSummaryConfig {
        RollingSummaryConfig {
            enabled: self.rolling_summaries_enabled(),
            rolling_10: self.rolling_10_enabled(),
            rolling_100: self.rolling_100_enabled(),
            snapshots: self.snapshot_summaries_enabled(),
            use_in_context: self.should_use_rolling_summaries_in_context(),
            max_age_hours: self.rolling_summary_max_age_hours,
            min_gap: self.rolling_summary_min_gap,
        }
    }

    /// Get all Phase 4 feature flags in a structured format
    pub fn get_phase4_features(&self) -> Phase4Features {
        Phase4Features {
            robust_memory: self.is_robust_memory_enabled(),
            rolling_summaries: self.rolling_summaries_enabled(),
            rolling_10: self.rolling_10_enabled(),
            rolling_100: self.rolling_100_enabled(),
            snapshot_summaries: self.snapshot_summaries_enabled(),
            use_rolling_in_context: self.should_use_rolling_summaries_in_context(),
            embedding_heads: self.get_embedding_heads(),
        }
    }
}

/// ── Phase 4: Configuration structures for monitoring ──

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RollingSummaryConfig {
    pub enabled: bool,
    pub rolling_10: bool,
    pub rolling_100: bool,
    pub snapshots: bool,
    pub use_in_context: bool,
    pub max_age_hours: u32,
    pub min_gap: usize,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Phase4Features {
    pub robust_memory: bool,
    pub rolling_summaries: bool,
    pub rolling_10: bool,
    pub rolling_100: bool,
    pub snapshot_summaries: bool,
    pub use_rolling_in_context: bool,
    pub embedding_heads: Vec<String>,
}

/// ── Default implementation ──
impl Default for MiraConfig {
    fn default() -> Self {
        Self::from_env()
    }
}

/// ── Tests ──
#[cfg(test)]
mod tests {
    use super::*;
    use std::env;
    use std::sync::Mutex;

    // Use a mutex to ensure tests that modify the environment run serially.
    lazy_static! {
        static ref ENV_MUTEX: Mutex<()> = Mutex::new(());
    }

    // Helper function to run tests in a clean environment.
    fn run_test<T>(test: T)
    where
        T: FnOnce() + std::panic::UnwindSafe,
    {
        let _lock = ENV_MUTEX.lock().unwrap();
        let original_vars: Vec<(String, Option<String>)> = [
            "MIRA_AGGRESSIVE_METADATA_ENABLED",
            // Add any other env vars your tests modify here
        ]
        .iter()
        .map(|&key| (key.to_string(), env::var(key).ok()))
        .collect();

        let result = std::panic::catch_unwind(test);

        // Teardown: Restore original environment variables
        for (key, val) in original_vars {
            unsafe {
                match val {
                    Some(v) => env::set_var(&key, v),
                    None => env::remove_var(&key),
                }
            }
        }
        
        assert!(result.is_ok());
    }


    #[test]
    fn test_default_config() {
        run_test(|| {
            let config = MiraConfig::from_env();
            assert_eq!(config.model, "gpt-5");
            assert_eq!(config.enable_web_search, true);
            assert_eq!(config.aggressive_metadata_enabled, false);
        });
    }

    #[test]
    fn test_phase4_robust_memory_disabled() {
        run_test(|| {
            // Explicitly remove the variable to ensure a clean state
            unsafe {
                env::remove_var("MIRA_AGGRESSIVE_METADATA_ENABLED");
            }
            let config = MiraConfig::from_env();
            assert!(!config.is_robust_memory_enabled());
            assert!(!config.rolling_summaries_enabled());
            assert_eq!(config.get_embedding_heads(), vec!["semantic"]);
        });
    }

    #[test]
    fn test_phase4_robust_memory_enabled() {
        run_test(|| {
            unsafe {
                env::set_var("MIRA_AGGRESSIVE_METADATA_ENABLED", "true");
            }
            let config = MiraConfig::from_env();

            assert!(config.is_robust_memory_enabled());
            assert!(config.rolling_summaries_enabled());
            let heads = config.get_embedding_heads();
            assert!(heads.contains(&"semantic".to_string()));
            assert!(heads.contains(&"code".to_string()));
            assert!(heads.contains(&"summary".to_string()));
            assert!(config.rolling_10_enabled());
            assert!(config.rolling_100_enabled());
            assert!(config.snapshot_summaries_enabled());
            assert!(config.should_use_rolling_summaries_in_context());
        });
    }

    #[test]
    fn test_phase4_rolling_summary_config() {
        run_test(|| {
            unsafe {
                env::set_var("MIRA_AGGRESSIVE_METADATA_ENABLED", "true");
            }
            let config = MiraConfig::from_env();
            let rolling_config = config.get_rolling_summary_config();
            assert!(rolling_config.enabled);
            assert!(rolling_config.rolling_10);
            assert!(rolling_config.rolling_100);
            assert!(rolling_config.snapshots);
            assert!(rolling_config.use_in_context);

            let phase4_features = config.get_phase4_features();
            assert!(phase4_features.robust_memory);
            assert!(phase4_features.rolling_summaries);
            assert_eq!(phase4_features.embedding_heads.len(), 3);
        });
    }

    #[test]
    fn test_chunk_size_configuration() {
        run_test(|| {
            let config = MiraConfig::from_env();
            assert_eq!(config.get_chunk_size_for_head("semantic"), 300);
            assert_eq!(config.get_chunk_size_for_head("code"), 256);
            assert_eq!(config.get_chunk_size_for_head("summary"), 600);
            assert_eq!(config.get_chunk_size_for_head("unknown"), 300);
            assert_eq!(config.get_chunk_overlap_for_head("semantic"), 100);
            assert_eq!(config.get_chunk_overlap_for_head("code"), 64);
            assert_eq!(config.get_chunk_overlap_for_head("summary"), 200);
        });
    }
}
