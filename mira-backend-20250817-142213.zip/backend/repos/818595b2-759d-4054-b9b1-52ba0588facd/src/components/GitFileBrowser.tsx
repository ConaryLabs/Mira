// src/components/GitFileBrowser.tsx
import React, { useState, useEffect } from 'react';
import {
  GitBranch,
  Folder,
  FolderOpen,
  File,
  FileText,
  FileCode,
  FileJson,
  ChevronRight,
  ChevronDown,
  Loader2,
  RefreshCw,
} from 'lucide-react';
import { API_BASE_URL } from '../services/config';

interface FileNode {
  name: string;
  path: string;
  node_type: 'file' | 'directory';
  size?: number;
  expanded?: boolean;
  children?: FileNode[];
}

interface GitFileBrowserProps {
  projectId: string;
  repoId: string;
  isDark?: boolean;
  onFileSelect?: (filePath: string) => void;
  selectedFile?: string;
}

export const GitFileBrowser: React.FC<GitFileBrowserProps> = ({
  projectId,
  repoId,
  isDark = false,
  onFileSelect,
  selectedFile,
}) => {
  const [files, setFiles] = useState<FileNode[]>([]);
  const [expandedPaths, setExpandedPaths] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadFileTree();
  }, [projectId, repoId]);

  const loadFileTree = async () => {
    try {
      setLoading(true);
      setError(null);
      
      const response = await fetch(
        `${API_BASE_URL}/projects/${projectId}/git/${repoId}/tree`
      );
      
      if (!response.ok) {
        throw new Error('Failed to load file tree');
      }
      
      const data = await response.json();
      
      // Convert flat node list to tree structure
      const tree = buildTreeFromNodes(data.nodes || []);
      setFiles(tree);
    } catch (error) {
      console.error('Error loading file tree:', error);
      setError('Failed to load repository files');
      setFiles([]);
    } finally {
      setLoading(false);
    }
  };

  const buildTreeFromNodes = (nodes: FileNode[]): FileNode[] => {
    // Create a map for quick lookup
    const nodeMap: Record<string, FileNode> = {};
    const rootNodes: FileNode[] = [];
    
    // First pass: create all nodes with empty children arrays
    nodes.forEach(node => {
      nodeMap[node.path] = {
        ...node,
        children: node.node_type === 'directory' ? [] : undefined,
        expanded: false,
      };
    });
    
    // Second pass: build the tree structure
    nodes.forEach(node => {
      const parts = node.path.split('/');
      
      if (parts.length === 1) {
        // Root level node
        rootNodes.push(nodeMap[node.path]);
      } else {
        // Find parent and add as child
        const parentPath = parts.slice(0, -1).join('/');
        const parent = nodeMap[parentPath];
        
        if (parent && parent.children) {
          parent.children.push(nodeMap[node.path]);
        } else {
          // If parent doesn't exist, treat as root
          rootNodes.push(nodeMap[node.path]);
        }
      }
    });
    
    // Sort directories first, then files, alphabetically
    const sortNodes = (nodes: FileNode[]) => {
      nodes.sort((a, b) => {
        if (a.node_type === b.node_type) {
          return a.name.localeCompare(b.name);
        }
        return a.node_type === 'directory' ? -1 : 1;
      });
      
      nodes.forEach(node => {
        if (node.children) {
          sortNodes(node.children);
        }
      });
    };
    
    sortNodes(rootNodes);
    return rootNodes;
  };

  const toggleExpand = (path: string) => {
    setExpandedPaths(prev => {
      const newSet = new Set(prev);
      if (newSet.has(path)) {
        newSet.delete(path);
      } else {
        newSet.add(path);
      }
      return newSet;
    });
  };

  const handleNodeClick = (node: FileNode) => {
    if (node.node_type === 'directory') {
      toggleExpand(node.path);
    } else {
      onFileSelect?.(node.path);
    }
  };

  const getFileIcon = (fileName: string) => {
    const ext = fileName.split('.').pop()?.toLowerCase();
    
    const iconMap: Record<string, JSX.Element> = {
      js: <FileCode className="w-4 h-4 text-yellow-500" />,
      jsx: <FileCode className="w-4 h-4 text-yellow-500" />,
      ts: <FileCode className="w-4 h-4 text-blue-500" />,
      tsx: <FileCode className="w-4 h-4 text-blue-500" />,
      py: <FileCode className="w-4 h-4 text-green-500" />,
      rs: <FileCode className="w-4 h-4 text-orange-500" />,
      go: <FileCode className="w-4 h-4 text-cyan-500" />,
      java: <FileCode className="w-4 h-4 text-red-500" />,
      json: <FileJson className="w-4 h-4 text-yellow-600" />,
      md: <FileText className="w-4 h-4 text-gray-500" />,
      txt: <FileText className="w-4 h-4 text-gray-500" />,
      toml: <FileText className="w-4 h-4 text-gray-600" />,
      yaml: <FileText className="w-4 h-4 text-purple-500" />,
      yml: <FileText className="w-4 h-4 text-purple-500" />,
    };
    
    return iconMap[ext || ''] || <File className="w-4 h-4 text-gray-400" />;
  };

  const formatFileSize = (bytes?: number) => {
    if (!bytes) return '';
    
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    return `${(bytes / Math.pow(1024, i)).toFixed(1)} ${sizes[i]}`;
  };

  const renderTree = (nodes: FileNode[], depth: number = 0) => {
    return nodes.map(node => {
      const isExpanded = expandedPaths.has(node.path);
      const isSelected = selectedFile === node.path;
      const isDirectory = node.node_type === 'directory';
      
      return (
        <div key={node.path}>
          <button
            onClick={() => handleNodeClick(node)}
            className={`w-full flex items-center gap-2 px-2 py-1 text-sm transition-colors ${
              isSelected
                ? isDark
                  ? 'bg-blue-600/20 text-blue-400'
                  : 'bg-blue-50 text-blue-700'
                : isDark
                  ? 'hover:bg-gray-700 text-gray-200'
                  : 'hover:bg-gray-100 text-gray-800'
            }`}
            style={{ paddingLeft: `${depth * 16 + 8}px` }}
          >
            {isDirectory ? (
              <>
                {isExpanded ? (
                  <ChevronDown className={`w-3 h-3 ${isDark ? 'text-gray-400' : 'text-gray-500'}`} />
                ) : (
                  <ChevronRight className={`w-3 h-3 ${isDark ? 'text-gray-400' : 'text-gray-500'}`} />
                )}
                {isExpanded ? (
                  <FolderOpen className="w-4 h-4 text-yellow-600" />
                ) : (
                  <Folder className="w-4 h-4 text-yellow-600" />
                )}
              </>
            ) : (
              <>
                <div className="w-3" />
                {getFileIcon(node.name)}
              </>
            )}
            <span className="flex-1 text-left truncate">{node.name}</span>
            {!isDirectory && node.size && (
              <span className={`text-xs ${isDark ? 'text-gray-500' : 'text-gray-400'}`}>
                {formatFileSize(node.size)}
              </span>
            )}
          </button>
          {isDirectory && isExpanded && node.children && node.children.length > 0 && (
            <div>{renderTree(node.children, depth + 1)}</div>
          )}
        </div>
      );
    });
  };

  if (loading) {
    return (
      <div className={`h-full flex flex-col ${isDark ? 'bg-gray-800' : 'bg-white'}`}>
        <div className={`sticky top-0 border-b px-3 py-2 ${
          isDark ? 'bg-gray-700 border-gray-600' : 'bg-gray-50 border-gray-200'
        }`}>
          <h3 className={`text-sm font-medium flex items-center gap-1 ${
            isDark ? 'text-gray-200' : 'text-gray-700'
          }`}>
            <GitBranch className="w-4 h-4" />
            Repository Files
          </h3>
        </div>
        <div className="flex-1 flex items-center justify-center">
          <div className="flex items-center gap-2 text-sm text-gray-500">
            <Loader2 className="w-4 h-4 animate-spin" />
            Loading repository files...
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className={`h-full flex flex-col ${isDark ? 'bg-gray-800' : 'bg-white'}`}>
        <div className={`sticky top-0 border-b px-3 py-2 ${
          isDark ? 'bg-gray-700 border-gray-600' : 'bg-gray-50 border-gray-200'
        }`}>
          <h3 className={`text-sm font-medium flex items-center gap-1 ${
            isDark ? 'text-gray-200' : 'text-gray-700'
          }`}>
            <GitBranch className="w-4 h-4" />
            Repository Files
          </h3>
        </div>
        <div className="flex-1 flex flex-col items-center justify-center p-4">
          <p className={`text-sm mb-3 ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>
            {error}
          </p>
          <button
            onClick={loadFileTree}
            className={`flex items-center gap-2 px-3 py-1.5 text-sm rounded border ${
              isDark
                ? 'border-gray-600 text-gray-300 hover:bg-gray-700'
                : 'border-gray-300 text-gray-600 hover:bg-gray-50'
            }`}
          >
            <RefreshCw className="w-4 h-4" />
            Retry
          </button>
        </div>
      </div>
    );
  }

  if (files.length === 0) {
    return (
      <div className={`h-full flex flex-col ${isDark ? 'bg-gray-800' : 'bg-white'}`}>
        <div className={`sticky top-0 border-b px-3 py-2 ${
          isDark ? 'bg-gray-700 border-gray-600' : 'bg-gray-50 border-gray-200'
        }`}>
          <h3 className={`text-sm font-medium flex items-center gap-1 ${
            isDark ? 'text-gray-200' : 'text-gray-700'
          }`}>
            <GitBranch className="w-4 h-4" />
            Repository Files
          </h3>
        </div>
        <div className="flex-1 flex items-center justify-center p-4 text-center">
          <div className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>
            <p className="mb-2">No files found in this repository</p>
            <p className="text-xs">The repository may be empty or still cloning</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={`h-full flex flex-col ${isDark ? 'bg-gray-800' : 'bg-white'}`}>
      <div className={`sticky top-0 border-b px-3 py-2 flex items-center justify-between ${
        isDark ? 'bg-gray-700 border-gray-600' : 'bg-gray-50 border-gray-200'
      }`}>
        <h3 className={`text-sm font-medium flex items-center gap-1 ${
          isDark ? 'text-gray-200' : 'text-gray-700'
        }`}>
          <GitBranch className="w-4 h-4" />
          Repository Files
        </h3>
        <button
          onClick={loadFileTree}
          className={`p-1 rounded transition-colors ${
            isDark
              ? 'hover:bg-gray-600 text-gray-400'
              : 'hover:bg-gray-200 text-gray-500'
          }`}
          title="Refresh"
        >
          <RefreshCw className="w-3 h-3" />
        </button>
      </div>
      <div className="flex-1 overflow-y-auto py-1">
        {renderTree(files)}
      </div>
    </div>
  );
};
