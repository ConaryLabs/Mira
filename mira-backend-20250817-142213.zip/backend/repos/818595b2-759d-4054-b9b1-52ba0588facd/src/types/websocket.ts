// src/types/websocket.ts
export interface WsChunk {
  type: 'chunk';
  content: string;
  mood?: string;  // Only mood is visible, not persona
}

export interface WsAside {
  type: 'aside';
  emotional_cue: string;
  intensity?: number;
}

export interface WsArtifact {
  type: 'artifact';
  artifact: {
    id: string;
    name: string;
    content: string;
    artifact_type: 'code' | 'document' | 'data';
    language?: string;
  };
}

export interface WsError {
  type: 'error';
  message: string;
  code?: string;
}

export interface WsDone {
  type: 'done';
}

// Additional types for backend compatibility
export interface WsStatus {
  type: 'status';
  message: string;
  detail?: string;
}

export interface WsComplete {
  type: 'complete';
  mood?: string;
  salience?: number;
  tags?: string[];
}

export interface WsSearchResults {
  type: 'search_results';
  results: Array<{
    content: string;
    relevance: number;
    metadata?: any;
  }>;
}

export interface WsSearchStatus {
  type: 'search_status';
  message: string;
}

export type WsServerMessage = 
  | WsChunk 
  | WsAside 
  | WsArtifact
  | WsError 
  | WsDone
  | WsStatus
  | WsComplete
  | WsSearchResults
  | WsSearchStatus;

export interface WsClientMessage {
  type: 'chat' | 'message' | 'typing';  // Added 'chat' to support backend expectation
  content?: string;
  persona?: string | null;  // DEPRECATED - will be ignored by backend
  active?: boolean;
  session_id?: string | null;
  project_id?: string | null;  // Added for project context
}
