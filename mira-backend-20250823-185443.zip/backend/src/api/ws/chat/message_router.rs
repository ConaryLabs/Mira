// src/api/ws/chat/message_router.rs
// PHASE 3 UPDATE: Fixed tool detection logic for better routing
// Handles routing between simple chat and tool-enabled chat based on CONFIG

use std::sync::Arc;
use std::net::SocketAddr;

use tracing::{debug, error, info};

use super::connection::WebSocketConnection;
use crate::api::ws::message::{WsClientMessage, MessageMetadata};
use crate::api::ws::chat_tools::handle_chat_message_with_tools;
use crate::state::AppState;
use crate::config::CONFIG;

pub struct MessageRouter {
    app_state: Arc<AppState>,
    connection: Arc<WebSocketConnection>,
    addr: SocketAddr,
}

impl MessageRouter {
    pub fn new(
        app_state: Arc<AppState>,
        connection: Arc<WebSocketConnection>,
        addr: SocketAddr,
    ) -> Self {
        Self {
            app_state,
            connection,
            addr,
        }
    }

    /// Main message routing entry point
    pub async fn route_message(&self, msg: WsClientMessage) -> Result<(), anyhow::Error> {
        match msg {
            WsClientMessage::Chat { content, project_id, metadata } => {
                self.handle_chat_message(content, project_id, metadata).await
            }
            WsClientMessage::Command { command, args } => {
                self.handle_command_message(command, args).await
            }
            WsClientMessage::Status { message } => {
                self.handle_status_message(message).await
            }
            WsClientMessage::Typing { active } => {
                self.handle_typing_message(active).await
            }
        }
    }

    /// Routes chat messages based on improved tool detection logic
    /// PHASE 3 FIX: Use should_use_tools() function for consistent logic
    async fn handle_chat_message(
        &self,
        content: String,
        project_id: Option<String>,
        metadata: Option<MessageMetadata>,
    ) -> Result<(), anyhow::Error> {
        info!("Chat message received: {} chars", content.len());
        self.connection.set_processing(true).await;

        // PHASE 3 FIX: Use the centralized tool detection logic
        let result = if should_use_tools(&metadata) {
            // Use tool-enabled streaming handler
            // Generate session ID dynamically for each WebSocket session
            let session_id = format!("ws-{}-{}", 
                chrono::Utc::now().timestamp(), 
                self.addr.port()
            );
            
            debug!("Routing to tool-enabled handler with session_id: {}", session_id);
            
            handle_chat_message_with_tools(
                content,
                project_id,
                metadata,
                self.app_state.clone(),
                self.connection.get_sender(),
                session_id,
            ).await
        } else {
            // Use simple streaming handler
            debug!("Routing to simple chat handler");
            self.handle_simple_chat_message(
                content,
                project_id,
            ).await
        };

        self.connection.set_processing(false).await;

        if let Err(e) = result {
            error!("Error handling chat message: {}", e);
            let _ = self.connection.send_error(&format!("Failed to process message: {}", e)).await;
        }

        Ok(())
    }

    /// Handle simple chat messages (non-tool enabled)
    async fn handle_simple_chat_message(
        &self,
        content: String,
        project_id: Option<String>,
    ) -> Result<(), anyhow::Error> {
        // Call the simple chat handler from the main chat module
        use super::handle_simple_chat_message;
        
        handle_simple_chat_message(
            content,
            project_id,
            self.app_state.clone(),
            self.connection.get_sender(),
            self.addr,
            self.connection.get_last_send_ref(),
        ).await
    }

    /// Handle command messages
    async fn handle_command_message(
        &self,
        command: String,
        args: Option<serde_json::Value>,
    ) -> Result<(), anyhow::Error> {
        info!("Command received: {} with args: {:?}", command, args);
        
        // Handle specific commands
        match command.as_str() {
            "ping" | "heartbeat" => {
                debug!("Heartbeat command received");
                self.connection.send_status("pong").await?;
            }
            _ => {
                debug!("Unknown command: {}", command);
            }
        }
        
        Ok(())
    }

    /// Handle status messages from client
    async fn handle_status_message(
        &self,
        message: String,
    ) -> Result<(), anyhow::Error> {
        debug!("Status message: {}", message);
        
        if message == "pong" || message.to_lowercase().contains("heartbeat") {
            debug!("Heartbeat acknowledged");
        }
        
        Ok(())
    }

    /// Handle typing indicator messages
    async fn handle_typing_message(
        &self,
        active: bool,
    ) -> Result<(), anyhow::Error> {
        debug!("Typing indicator: {}", active);
        
        // Could forward to other connected clients in the future
        // For now, just acknowledge
        Ok(())
    }
}

/// PHASE 3 IMPROVED: Enhanced tool detection logic
/// This encapsulates the routing logic for consistent reuse across the system
pub fn should_use_tools(metadata: &Option<MessageMetadata>) -> bool {
    // Must have tools enabled globally
    if !CONFIG.enable_chat_tools {
        return false;
    }
    
    // Tools are enabled - now check if context suggests tool usage would be beneficial
    match metadata {
        Some(meta) => {
            // If we have specific file context, tools are likely beneficial
            if meta.file_path.is_some() {
                return true;
            }
            
            // If we have repository context, tools are likely beneficial  
            if meta.repo_id.is_some() || meta.attachment_id.is_some() {
                return true;
            }
            
            // If we have language context, user might be asking about code
            if meta.language.is_some() {
                return true;
            }
            
            // If we have a text selection, user might want to operate on it
            if meta.selection.is_some() {
                return true;
            }
            
            // Even empty metadata suggests the client is tool-capable
            // Let the LLM decide if tools are actually needed
            true
        }
        None => {
            // No metadata means basic chat - use simple handler
            // The client didn't indicate any context that would benefit from tools
            false
        }
    }
}

/// Utility function to extract file context from metadata
pub fn extract_file_context(metadata: &Option<MessageMetadata>) -> Option<String> {
    metadata.as_ref().and_then(|meta| {
        if let Some(file_path) = &meta.file_path {
            Some(format!("File: {}", file_path))
        } else if let Some(repo_id) = &meta.repo_id {
            Some(format!("Repository: {}", repo_id))
        } else if let Some(attachment_id) = &meta.attachment_id {
            Some(format!("Attachment: {}", attachment_id))
        } else {
            None
        }
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::api::ws::message::MessageMetadata;

    #[test]
    fn test_should_use_tools() {
        // Test with metadata containing file path
        let metadata_with_file = Some(MessageMetadata {
            file_path: Some("test.rs".to_string()),
            repo_id: None,
            attachment_id: None,
            language: None,
            selection: None,
        });
        
        // Test with metadata containing repo ID
        let metadata_with_repo = Some(MessageMetadata {
            file_path: None,
            repo_id: Some("repo-123".to_string()),
            attachment_id: None,
            language: None,
            selection: None,
        });
        
        // Test with metadata containing language
        let metadata_with_language = Some(MessageMetadata {
            file_path: None,
            repo_id: None,
            attachment_id: None,
            language: Some("rust".to_string()),
            selection: None,
        });
        
        // Test with no metadata
        let no_metadata = None;
        
        // Test with completely empty metadata
        let empty_metadata = Some(MessageMetadata {
            file_path: None,
            repo_id: None,
            attachment_id: None,
            language: None,
            selection: None,
        });
        
        // These tests depend on CONFIG.enable_chat_tools being true (Phase 3 default)
        if CONFIG.enable_chat_tools {
            assert!(should_use_tools(&metadata_with_file), "Should use tools for file context");
            assert!(should_use_tools(&metadata_with_repo), "Should use tools for repo context");
            assert!(should_use_tools(&metadata_with_language), "Should use tools for language context");
            assert!(!should_use_tools(&no_metadata), "Should not use tools without metadata");
            assert!(should_use_tools(&empty_metadata), "Should use tools for empty metadata (tool-capable client)");
        } else {
            // If tools are disabled, none should use tools
            assert!(!should_use_tools(&metadata_with_file));
            assert!(!should_use_tools(&metadata_with_repo));
            assert!(!should_use_tools(&metadata_with_language));
            assert!(!should_use_tools(&no_metadata));
            assert!(!should_use_tools(&empty_metadata));
        }
    }

    #[test]
    fn test_extract_file_context() {
        let metadata_with_file = Some(MessageMetadata {
            file_path: Some("src/main.rs".to_string()),
            repo_id: None,
            attachment_id: None,
            language: None,
            selection: None,
        });
        
        let metadata_with_repo = Some(MessageMetadata {
            file_path: None,
            repo_id: Some("repo-123".to_string()),
            attachment_id: None,
            language: None,
            selection: None,
        });
        
        let metadata_with_attachment = Some(MessageMetadata {
            file_path: None,
            repo_id: None,
            attachment_id: Some("attach-456".to_string()),
            language: None,
            selection: None,
        });
        
        let empty_metadata = Some(MessageMetadata {
            file_path: None,
            repo_id: None,
            attachment_id: None,
            language: None,
            selection: None,
        });
        
        assert_eq!(extract_file_context(&metadata_with_file), Some("File: src/main.rs".to_string()));
        assert_eq!(extract_file_context(&metadata_with_repo), Some("Repository: repo-123".to_string()));
        assert_eq!(extract_file_context(&metadata_with_attachment), Some("Attachment: attach-456".to_string()));
        assert_eq!(extract_file_context(&empty_metadata), None);
        assert_eq!(extract_file_context(&None), None);
    }
}
