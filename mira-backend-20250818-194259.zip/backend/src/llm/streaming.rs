// src/llm/streaming.rs
// Updated streaming implementation to handle GPT‑5 Responses API events as of 2025‑08‑19.
//
// This module converts Server‑Sent Events (SSE) from OpenAI's Responses API into a
// stream of `StreamEvent` values.  It supports both legacy event types
// (`response.output_text.delta`, `response.message.delta`) and newer ones
// (`response.text.delta`, `response.content_part.added`, etc.).  The
// streaming response will yield `Delta` events with partial text as soon as
// they arrive, and a final `Done` event once the stream completes.  If an
// error occurs, an `Error` event is emitted.

use anyhow::{anyhow, Result};
use futures::{Stream, StreamExt};
use serde_json::Value;
use std::pin::Pin;
use tracing::{debug, info, warn};

use crate::llm::client::{OpenAIClient, ResponseStream};

/// Events emitted while streaming a response from GPT‑5.
#[derive(Debug, Clone)]
pub enum StreamEvent {
    /// A chunk of plain text from the model.
    Delta(String),
    /// Final result with the full text and optionally the raw JSON of the last SSE frame.
    Done { full_text: String, raw: Option<Value> },
    /// An error occurred while streaming.
    Error(String),
}

/// Convenience alias for the returned stream type.
pub type StreamResult = Pin<Box<dyn Stream<Item = Result<StreamEvent>> + Send>>;

/// Public entrypoint used by other modules to start a streaming response.
pub async fn start_response_stream(
    client: &OpenAIClient,
    user_text: &str,
    system_prompt: Option<&str>,
    structured_json: bool,
) -> Result<StreamResult> {
    stream_response(client, user_text, system_prompt, structured_json).await
}

/// Internal helper that constructs the request body and processes SSE frames.
/// If `structured_json` is true, we expect the model to return a JSON object
/// matching the schema defined in `api/two_phase.rs` and will buffer the
/// deltas until a complete JSON can be parsed.  Otherwise, we stream plain
/// text as it arrives.
pub async fn stream_response(
    client: &OpenAIClient,
    user_text: &str,
    system_prompt: Option<&str>,
    structured_json: bool,
) -> Result<StreamResult> {
    info!("🚀 Starting response stream - structured_json: {}", structured_json);

    // Build the input array: optional system message followed by user message.
    let input = vec![
        serde_json::json!({
            "role": "system",
            "content": [{ "type": "input_text", "text": system_prompt.unwrap_or("") }]
        }),
        serde_json::json!({
            "role": "user",
            "content": [{ "type": "input_text", "text": user_text }]
        }),
    ];

    // Construct the request body for the Responses API.  We always set `stream: true`.
    let mut body = serde_json::json!({
        "model": client.model(),
        "input": input,
        "text": { "verbosity": norm_verbosity(client.verbosity()) },
        "reasoning": { "effort": norm_effort(client.reasoning_effort()) },
        "max_output_tokens": client.max_output_tokens(),
        "stream": true,
    });
    // If structured_json, request the JSON schema.
    if structured_json {
        body["text"]["format"] = serde_json::json!({
            "type": "json_schema",
            "name": "mira_response",
            "schema": {
                "type": "object",
                "properties": {
                    "output": { "type": "string" },
                    "mood": { "type": "string" },
                    "salience": { "type": "integer", "minimum": 0, "maximum": 10 },
                    "summary": { "type": "string" },
                    "memory_type": { "type": "string" },
                    "tags": { "type": "array", "items": { "type": "string" } },
                    "intent": { "type": "string" },
                    "monologue": { "type": ["string", "null"] },
                    "reasoning_summary": { "type": ["string", "null"] }
                },
                "required": [
                    "output", "mood", "salience", "summary", "memory_type",
                    "tags", "intent", "monologue", "reasoning_summary"
                ],
                "additionalProperties": false
            },
            "strict": true
        });
    }

    info!("📤 Sending request to OpenAI Responses API");
    let sse: ResponseStream = client.stream_response(body).await?;
    info!("✅ SSE stream started successfully");

    // Shared state across frames: the raw text, buffered JSON, flags, and last raw frame.
    let raw_text = std::sync::Arc::new(tokio::sync::Mutex::new(String::new()));
    let json_buf = std::sync::Arc::new(tokio::sync::Mutex::new(String::new()));
    let json_complete = std::sync::Arc::new(std::sync::atomic::AtomicBool::new(false));
    let last_raw = std::sync::Arc::new(tokio::sync::Mutex::new(None::<Value>));
    let frame_no = std::sync::Arc::new(std::sync::atomic::AtomicUsize::new(0));

    // Process each SSE frame and map it to a StreamEvent.  Many frames will not
    // produce output (they carry progress or other metadata) and thus return
    // `Err(anyhow!(...))` which are filtered out below.  Only frames that
    // yield output events are returned as `Ok(StreamEvent)`.
    let stream = sse
        .then({
            let raw_text = raw_text.clone();
            let json_buf = json_buf.clone();
            let json_complete = json_complete.clone();
            let last_raw = last_raw.clone();
            let frame_no = frame_no.clone();

            move |item| {
                let raw_text = raw_text.clone();
                let json_buf = json_buf.clone();
                let json_complete = json_complete.clone();
                let last_raw = last_raw.clone();
                let frame_no = frame_no.clone();

                async move {
                    match item {
                        Ok(v) => {
                            // Log the event
                            let n = frame_no.fetch_add(1, std::sync::atomic::Ordering::SeqCst);
                            let short = serde_json::to_string(&v).unwrap_or_default();
                            info!("📦 SSE frame #{}: {}", n, truncate_for_log(&short, 200));

                            // Save the last raw frame
                            {
                                let mut g = last_raw.lock().await;
                                *g = Some(v.clone());
                            }

                            // Determine the event type
                            let typ = v.get("type").and_then(|x| x.as_str()).unwrap_or("");

                            match typ {
                                // Response created
                                "response.created" => {
                                    info!("🚀 Response created: {}", v.pointer("/response/id").and_then(|x| x.as_str()).unwrap_or("unknown"));
                                }
                                // Response in progress
                                "response.in_progress" => {
                                    info!("⏳ Response in progress");
                                }
                                // Legacy output item added (contains no text itself)
                                "response.output_item.added" => {
                                    debug!("📝 output_item.added");
                                    // In some cases the API may emit text here for older models; fall through
                                }
                                // Newer content part added event.  Attempt to extract a text or delta field.
                                "response.content_part.added" => {
                                    if let Some(part) = v.get("content_part") {
                                        // Try text first, then delta
                                        if let Some(delta) = part.get("text").and_then(|t| t.as_str()).or_else(|| part.get("delta").and_then(|d| d.as_str())) {
                                            {
                                                let mut g = raw_text.lock().await;
                                                g.push_str(delta);
                                            }
                                            if structured_json {
                                                let mut jb = json_buf.lock().await;
                                                jb.push_str(delta);
                                                if try_parse_complete_json(&jb) {
                                                    if !json_complete.swap(true, std::sync::atomic::Ordering::SeqCst) {
                                                        info!("📄 Complete structured JSON detected (from content_part.added)");
                                                        return Ok(StreamEvent::Delta(jb.clone()));
                                                    }
                                                }
                                            } else {
                                                return Ok(StreamEvent::Delta(delta.to_string()));
                                            }
                                        }
                                    }
                                }
                                // Legacy output text delta
                                "response.output_text.delta" => {
                                    if let Some(delta) = v.get("delta").and_then(|d| d.as_str()) {
                                        {
                                            let mut g = raw_text.lock().await;
                                            g.push_str(delta);
                                        }
                                        if structured_json {
                                            let mut jb = json_buf.lock().await;
                                            jb.push_str(delta);
                                            if try_parse_complete_json(&jb) {
                                                if !json_complete.swap(true, std::sync::atomic::Ordering::SeqCst) {
                                                    info!("📄 Complete structured JSON detected (from output_text.delta)");
                                                    return Ok(StreamEvent::Delta(jb.clone()));
                                                }
                                            }
                                        } else {
                                            return Ok(StreamEvent::Delta(delta.to_string()));
                                        }
                                    }
                                }
                                // Newer text delta event (GPT‑5).  Equivalent to output_text.delta.
                                "response.text.delta" => {
                                    if let Some(delta) = v.get("delta").and_then(|d| d.as_str()) {
                                        {
                                            let mut g = raw_text.lock().await;
                                            g.push_str(delta);
                                        }
                                        if structured_json {
                                            let mut jb = json_buf.lock().await;
                                            jb.push_str(delta);
                                            if try_parse_complete_json(&jb) {
                                                if !json_complete.swap(true, std::sync::atomic::Ordering::SeqCst) {
                                                    info!("📄 Complete structured JSON detected (from text.delta)");
                                                    return Ok(StreamEvent::Delta(jb.clone()));
                                                }
                                            }
                                        } else {
                                            return Ok(StreamEvent::Delta(delta.to_string()));
                                        }
                                    }
                                }
                                // Complex message delta format: list of parts; used by some models
                                "response.message.delta" => {
                                    if let Some(parts) = v.get("delta").and_then(|d| d.get("content")).and_then(|c| c.as_array()) {
                                        let mut combined = String::new();
                                        for part in parts {
                                            if let Some(txt) = part.get("text").and_then(|t| t.get("value")).and_then(|x| x.as_str()) {
                                                combined.push_str(txt);
                                            } else if let Some(txt) = part.get("delta").and_then(|d| d.as_str()) {
                                                combined.push_str(txt);
                                            }
                                        }
                                        if !combined.is_empty() {
                                            {
                                                let mut g = raw_text.lock().await;
                                                g.push_str(&combined);
                                            }
                                            if structured_json {
                                                let mut jb = json_buf.lock().await;
                                                jb.push_str(&combined);
                                                if try_parse_complete_json(&jb) {
                                                    if !json_complete.swap(true, std::sync::atomic::Ordering::SeqCst) {
                                                        info!("📄 Complete structured JSON detected (from message.delta)");
                                                        return Ok(StreamEvent::Delta(jb.clone()));
                                                    }
                                                }
                                            } else {
                                                return Ok(StreamEvent::Delta(combined));
                                            }
                                        }
                                    }
                                }
                                // Completion markers.  At this point we emit a Done event with the full text.
                                "response.output_text.done" | "response.content_part.done" | "response.text.done" => {
                                    debug!("✅ text/content part done");
                                }
                                "response.output_item.done" => {
                                    info!("✅ Output item completed");
                                    if structured_json {
                                        let jb = json_buf.lock().await;
                                        if !jb.is_empty() && try_parse_complete_json(&jb) {
                                            if !json_complete.swap(true, std::sync::atomic::Ordering::SeqCst) {
                                                info!("📤 Emitting buffered JSON at output_item.done");
                                                return Ok(StreamEvent::Delta(jb.clone()));
                                            }
                                        }
                                    }
                                    let full = raw_text.lock().await.clone();
                                    return Ok(StreamEvent::Done { full_text: full, raw: Some(v) });
                                }
                                "response.done" => {
                                    info!("🎉 Response complete");
                                    if structured_json {
                                        let jb = json_buf.lock().await;
                                        if !jb.is_empty() && try_parse_complete_json(&jb) {
                                            if !json_complete.swap(true, std::sync::atomic::Ordering::SeqCst) {
                                                info!("📤 Emitting buffered JSON at response.done");
                                                return Ok(StreamEvent::Delta(jb.clone()));
                                            }
                                        }
                                    }
                                    let full = raw_text.lock().await.clone();
                                    return Ok(StreamEvent::Done { full_text: full, raw: Some(v) });
                                }
                                _ => {
                                    debug!("📋 Other event type: {}", typ);
                                }
                            }

                            Err(anyhow!("no outward event in this frame"))
                        }
                        Err(e) => {
                            warn!("❌ SSE error: {}", e);
                            Ok(StreamEvent::Error(e.to_string()))
                        }
                    }
                }
            }
        })
        .filter_map(|r| async move {
            match r {
                Ok(ev) => Some(Ok(ev)),
                Err(_) => None,
            }
        });

    Ok(Box::pin(stream))
}

// === strict literal normalizers ===

fn norm_verbosity(v: &str) -> &'static str {
    match v.to_ascii_lowercase().as_str() {
        "low" => "low",
        "medium" => "medium",
        "high" => "high",
        _ => "medium",
    }
}

fn norm_effort(r: &str) -> &'static str {
    match r.to_ascii_lowercase().as_str() {
        "minimal" => "minimal",
        "medium" => "medium",
        "high" => "high",
        _ => "medium",
    }
}

fn truncate_for_log(s: &str, max: usize) -> String {
    if s.len() <= max {
        return s.to_string();
    }
    let mut end = max;
    while !s.is_char_boundary(end) && end > 0 {
        end -= 1;
    }
    format!("{}...", &s[..end])
}

fn try_parse_complete_json(buf: &str) -> bool {
    serde_json::from_str::<Value>(buf).is_ok()
}
